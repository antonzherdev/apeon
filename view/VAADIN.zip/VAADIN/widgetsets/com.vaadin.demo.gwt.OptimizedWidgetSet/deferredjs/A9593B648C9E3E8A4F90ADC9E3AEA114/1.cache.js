function TG(){}
function R7(){}
function wcb(){}
function Zcb(){}
function ddb(){}
function rdb(){}
function U7(){return SC}
function dH(){return iA}
function Qcb(){return CD}
function bdb(){return zD}
function qdb(){return AD}
function vdb(){return BD}
function Rcb(){return this.i}
function T7(){return zcb(new wcb)}
function iO(a,b,c){eO(a,b,c)}
function dO(a,b,c,d){bO(a,b);a.pc(b,c,d)}
function Hcb(a,b){return J3(a.d,a,b)}
function Scb(a){return this.o.od(a)}
function adb(a){return Hcb(this.a,a)}
function cdb(a,b){return gN(this.a,a,b)}
function udb(a,b){a.a=Hub(new Fub);a.b=b;return a}
function ktb(a,b){tpb(a);gpb(a,b);return a}
function _cb(a,b,c,d){a.a=d;a.g=b;a.b=c;return a}
function $N(a,b){a.D=BX(new zX,a);a.nb=b;return a}
function jdb(a){if(a.b){return a.b.r.Uc()+Okb(a.b)}else{return 0}}
function QN(a,b){if(b<0||b>a.D.c){throw Vmb(new Tmb)}}
function bO(a,b){if(b.mb!=a){throw Mmb(new Jmb,aSb)}}
function ndb(a){if(!a.c){return false}if(a.g){return false}else{mdb(a);return true}}
function kdb(a){var b;if(a.b){b=a.b.r.Vc()+Rkb(a.b);return b}else{return 0}}
function gdb(a,b,c){a.k=c;a.h=b[1][cSb];a.d=b[1][dSb];odb(a,b);return a}
function PU(a,b,c){b-=hm((tl(),$doc));c-=im($doc);eO(a,b,c)}
function PN(a,b,c){var d;QN(a,c);if(b.mb==a){d=EX(a.D,b);d<c&&--c}return c}
function aO(a,b,c,d){var e;pN(b);e=a.D.c;a.pc(b,c,d);SN(a,b,a.nb,e,true)}
function eO(a,b,c){var d;d=a.nb;if(b==-1&&c==-1){fO(d)}else{d.style[nzb]=DAb;d.style[lzb]=b+Zyb;d.style[mzb]=c+Zyb}}
function gpb(a,b){var c,d;for(d=b.pd().oc();d.Sb();){c=py(d.Tb(),51);a.wd(c.yd(),c.zd())}}
function Kcb(a){var b,c;for(c=Mub(a,0);c.b!=c.d.a;){b=py(Zub(c),37);mdb(b)}}
function Lcb(a){var b,c;for(c=Mub(a,0);c.b!=c.d.a;){b=py(Zub(c),37);if(!b.f){mdb(b);$ub(c)}}}
function idb(a){var b,c;c=a.k.g[a.d];for(b=1;b<a.e;++b){c+=a.k.u+a.k.g[a.d+b]}return c}
function hdb(a){var b,c;b=a.k.r[a.h];for(c=1;c<a.i;++c){b+=a.k.v+a.k.r[a.h+c]}return b}
function Gqb(a,b){var c,d;for(c=0,d=a.b;c<d;++c){if(!b?Mrb(a,c)==null:(b==null?null:b)===zy(Mrb(a,c))){return c}}return -1}
function Ocb(a){var b,c;b=Yx(vF,263,-1,a.length,1);for(c=0;c<b.length;++c){b[c]=a[c]}return b}
function Tcb(a,b){var c;c=py(this.w.xd(a),88);if(!c){return}blb(c,b);this.w.wd(b,c);this.o.wd(py(b,66),py(this.o.qd(a),37))}
function Pcb(a){var b;b=py(this.o.qd(a),37);return D2(new A2,idb(b)-Rkb(b.b),hdb(b)-Okb(b.b))}
function Xcb(a,b){var c;c=py(this.w.qd(a),88);!!c&&elb(c,b,this.d);if(!this.p){pdb(py(this.o.qd(a),37),b);Zrb(this.d.c,a)}}
function SN(a,b,c,d,e){d=PN(a,b,d);pN(b);FX(a.D,b,d);e?oL(c,b.nb,d):c.appendChild(b.nb);rN(b,a)}
function ldb(a,b,c){if(!!a.b&&a.b.jb){dO(a.k.a,a.b,b,c);Xkb(a.b,idb(a),hdb(a));a.b.a=o8(new l8,a.a);dlb(a.b,idb(a),hdb(a))}}
function ZN(a){$N(a,Yl((tl(),$doc),hxb));a.nb.style[nzb]=KAb;a.nb.style[EAb]=xAb;return a}
function eH(){_G=true;$G=(bH(),new TG);tj((qj(),pj),1);!!$stats&&$stats(Zj($Rb,Ywb,null,null));$G.Qb();!!$stats&&$stats(Zj($Rb,_Rb,null,null))}
function Fcb(a){var b,c,d,e,f,g,h;if(!Qnb(Mwb,a.h)){h=a.m[0];for(g=1;g<a.m.length;++g){h+=a.v+a.m[g]}b=(parseInt(a.nb[bzb])||0)-a.k;f=b-h;d=0;if(f>0){for(g=0;g<a.r.length;++g){e=~~(f*a.q[g]/1000);a.r[g]=a.m[g]+e;d+=e}f-=d;c=0;while(f>0){++a.r[c%a.r.length];--f;++c}}}}
function Gcb(a,b){var c,d,e;e=b[1][cSb];d=b[1][dSb];c=a.b[d][e];if(!c){c=gdb(new ddb,b,a);a.b[d][e]=c}else{odb(c,b)}return c}
function hH(){var a,c,d;while(YG){d=di;YG=YG.a;!YG&&(ZG=null);if(!d){(H7(),G7).wd(CD,new R7);yZ()}else{try{(H7(),G7).wd(CD,new R7);yZ()}catch(a){a=UF(a);if(sy(a,5)){c=a;K4.Ic(c)}else throw a}}}}
function Jcb(a){var b,c,d,e,f,g;f=0;g=0;for(d=0;d<a.b.length;++d){g=0;for(e=0;e<a.b[d].length;++e){c=a.b[d][e];!!c&&ldb(c,f,g);g+=a.r[e]+a.v}f+=a.g[d]+a.u}Qnb(Mwb,a.x)?(a.a.nb.style[Yyb]=f-a.u+Zyb,undefined):(a.a.nb.style[Yyb]=Mwb,undefined);Qnb(Mwb,a.h)?(b=g-a.v):(b=(parseInt(a.nb[bzb])||0)-a.k);a.a.nb.style[$yb]=b+Zyb}
function $x(a,b,c,d,e,f,g){var h,i,k,l;k=d[e];i=e==f-1;l=Wx(i?g:0,k);fy();iy(l,dy,ey);l.aC=a[e];l.tI=b[e];l.qI=c[e];if(!i){++e;for(h=0;h<k;++h){l[h]=$x(a,b,c,d,e,f,g)}}return l}
function Ecb(a){var b,c,d,e,f,g,h;if(!Qnb(Mwb,a.x)){h=a.l[0];for(g=1;g<a.l.length;++g){h+=a.u+a.l[g]}a.a.nb.style[Yyb]=Mwb;b=parseInt(a.a.nb[czb])||0;f=b-h;d=0;if(f>0){for(g=0;g<a.g.length;++g){e=~~(f*a.e[g]/1000);a.g[g]=a.l[g]+e;d+=e}f-=d;c=0;while(f>0){++a.g[c%a.g.length];--f;++c}}}}
function zcb(a){a.nb=Yl((tl(),$doc),hxb);a.i=Yl($doc,hxb);a.a=ZN(new wM);a.w=itb(new gtb);a.o=itb(new gtb);a.c=_cb(new Zcb,a,Oxb,a);a.f=Hub(new Fub);a.s=Hub(new Fub);a.nb.appendChild(a.i);a.nb[_yb]=bSb;PS(a,a.a);return a}
function pdb(a,b){if(!!b&&!Boolean(b[1][NCb])){$yb in b[1]&&b[1][$yb].indexOf(VBb)!=-1?(a.f=true):(a.f=false);if(Yyb in b[1]){a.l=a.g=b[1][Yyb].indexOf(VBb)!=-1;$yb in b[1]&&(a.l=false)}else{a.l=!($yb in b[1]);a.g=false}}}
function Acb(a){var b,c,d;for(c=0;c<a.b.length;++c){for(d=0;d<a.b[c].length;++d){b=a.b[c][d];if(b){if(!!b.b&&b.l){b.b.nb.style[Yyb]=idb(b)+Zyb;hlb(b.b)}b.i==1?!b.f&&a.r[d]<jdb(b)&&(a.r[d]=jdb(b)):Ncb(a,b)}}}Dcb(a);a.m=Ocb(a.r)}
function Mcb(a,b){var c,d,e,f;c=null;for(e=Mub(a.f,0);e.b!=e.d.a;){d=py(Zub(e),89);if(d.b<b.e){continue}else{c=d;break}}if(!c){c=udb(new rdb,b.e);Kub(a.f,c)}else if(c.b!=b.e){f=udb(new rdb,b.e);Lrb(a.f,Gqb(a.f,c),f);c=f}Iub(c.a,b)}
function Ncb(a,b){var c,d,e,f;c=null;for(e=Mub(a.s,0);e.b!=e.d.a;){d=py(Zub(e),89);if(d.b<b.i){continue}else{c=d;break}}if(!c){c=udb(new rdb,b.i);Kub(a.s,c)}else if(c.b!=b.i){f=udb(new rdb,b.i);Lrb(a.s,Gqb(a.s,c),f);c=f}Iub(c.a,b)}
function Vcb(a){var b,c,d,e;this.nb.style[$yb]=a;if(!Qnb(a,this.h)){this.h=a;if(this.p){this.t=true}else{Fcb(this);Jcb(this);for(c=(d=fpb(this.o).b.oc(),lrb(new jrb,d));c.a.Sb();){b=py((e=py(c.a.Tb(),51),e.yd()),66);i$(this.d,py(b,36))}}}}
function Ccb(a){var b,c,d,e,f,g,h,i,k,l;for(h=Mub(a.f,0);h.b!=h.d.a;){g=py(Zub(h),89);for(d=Mub(g.a,0);d.b!=d.d.a;){c=py(Zub(d),37);l=c.g?0:kdb(c);b=a.g[c.d];for(f=1;f<c.e;++f){b+=a.u+a.g[c.d+f]}if(b<l){i=l-b;k=~~(i/c.e);for(f=0;f<c.e;++f){e=c.d+f;a.g[e]+=k;i-=k}if(i>0){for(f=0;f<c.e;++f){e=c.d+f;a.g[e]+=1;i-=1;if(i==0){break}}}}}}}
function Dcb(a){var b,c,d,e,f,g,h,i,k,l;for(h=Mub(a.s,0);h.b!=h.d.a;){g=py(Zub(h),89);for(d=Mub(g.a,0);d.b!=d.d.a;){c=py(Zub(d),37);e=c.f?0:jdb(c);b=a.r[c.h];for(f=1;f<c.i;++f){b+=a.v+a.r[c.h+f]}if(b<e){i=e-b;l=~~(i/c.i);for(f=0;f<c.i;++f){k=c.h+f;a.r[k]+=l;i-=l}if(i>0){for(f=0;f<c.i;++f){k=c.h+f;a.r[k]+=1;i-=1;if(i==0){break}}}}}}}
function mdb(a){var b;b=d$(a.k.d,a.c);if(!a.b||a.b.p!=b){if(a.k.w.od(b)){a.b=py(a.k.w.qd(b),88);a.b.nb.style[Yyb]=Mwb;a.b.nb.style[$yb]=Mwb}else{a.b=Gkb(new Dkb,py(b,36),0);a.k.w.wd(py(b,36),a.b);a.b.nb.style[Yyb]=Mwb;aO(a.k.a,a.b,0,0)}a.k.o.wd(b,a)}Ukb(a.b,a.c,a.k.d,-1);a.k.t&&(D3(),Boolean(a.c[1][NCb]))&&i$(a.k.d,a.b.p);hlb(a.b);a.k.n.xd(b)}
function odb(a,b){var c,d,e;a.e=oSb in b[1]?b[1][oSb]:1;a.i=zHb in b[1]?b[1][zHb]:1;for(c=0;c<a.e;++c){for(d=0;d<a.i;++d){(c>0||d>0)&&by(a.k.b[a.d+c],a.h+d,null)}}b=b[2];if(a.c){if(!b){a.b=null}else if(!!a.b&&a.b.p!=d$(a.k.d,b)){a.b=null;e=d$(a.k.d,b);if(a.k.w.od(e)){a.b=py(a.k.w.qd(e),88);a.b.nb.style[Yyb]=Mwb;a.b.nb.style[$yb]=Mwb;a.k.o.wd(e,a)}}}a.c=b;pdb(a,b)}
function Wcb(a){var b,c,d,e,f,g,h,i,k,l,m,n,o,p,q,r,s,t,u,v;this.nb.style[Yyb]=a;if(!Qnb(a,this.x)){this.x=a;if(this.p){this.t=true}else{o=Ocb(this.g);Ecb(this);h=false;g=null;for(i=0;i<o.length;++i){if(this.g[i]!=o[i]){f=this.b[i];for(k=0;k<f.length;++k){b=f[k];if(!!b&&!!b.b&&b.l){Xkb(b.b,idb(b),hdb(b));i$(this.d,b.b.p);hlb(b.b);l=jdb(b);if(this.g[i]<o[i]&&l>this.m[k]&&b.i==1){this.m[k]=l;if(l>this.r[k]){this.r[k]=l;h=true}}else if(l<this.m[k]){!g&&(g=qtb(new otb));ttb(g,hnb(k))}}}}}if(g){r=false;for(q=(s=fpb(g.a).b.oc(),lrb(new jrb,s));q.a.Sb();){p=py((t=py(q.a.Tb(),51),t.yd()),43);n=this.m[p.a];m=0;for(e=0;e<this.g.length;++e){d=this.b[e][p.a];!!d&&!d.f&&jdb(d)>m&&(m=jdb(d))}if(m<n){this.m[p.a]=this.r[p.a]=m;r=true}}if(r){Dcb(this);this.m=Ocb(this.r);h=true}}Jcb(this);for(c=(u=fpb(this.o).b.oc(),lrb(new jrb,u));c.a.Sb();){b=py((v=py(c.a.Tb(),51),v.yd()),66);i$(this.d,py(b,36))}h&&Qnb(Mwb,this.h)&&Q3(this,false)}}}
function Ucb(a){var b,c,d,e,f,g,h,i,k,l,m,n,o,p,q,r,s,t,u,v,w,x;n=false;s=false;t=false;o=parseInt(this.a.nb[bzb])||0;p=parseInt(this.a.nb[czb])||0;(Qnb(Mwb,this.x)||Qnb(Mwb,this.h))&&(n=true);g=Wrb(new Trb);h=Wrb(new Trb);for(r=a.oc();r.Sb();){q=py(r.Tb(),66);c=py(this.o.qd(q),37);if(!c.f||!c.g){c.b.nb.style[Yyb]=Mwb;c.b.nb.style[$yb]=Mwb;hlb(c.b);flb(c.b);x=kdb(c);b=this.g[c.d];for(l=1;l<c.e;++l){b+=this.u+this.g[c.d+l]}if(b<x){n=true;c.e==1?(this.g[c.d]=this.l[c.d]=x):(s=true)}else b!=x&&Zrb(g,hnb(c.d));k=jdb(c);b=this.r[c.h];for(l=1;l<c.i;++l){b+=this.v+this.r[c.h+l]}if(b<k){n=true;c.i==1?(this.r[c.h]=this.m[c.h]=k):(t=true)}else b!=k&&Zrb(h,hnb(c.h))}}if(g.b>0){for(e=Uqb(new Rqb,g);e.a<e.c.ld();){d=py(Wqb(e),43);f=0;for(l=0;l<this.r.length;++l){c=this.b[d.a][l];if(!!c&&!!c.c&&!c.g&&c.e==1){x=kdb(c);x>f&&(f=x)}}this.l[d.a]=f}n=true;this.g=Ocb(this.l);Ccb(this);s=false}s&&Ccb(this);if(h.b>0){n=true;for(w=Uqb(new Rqb,h);w.a<w.c.ld();){v=py(Wqb(w),43);u=this.m[v.a]=0;for(l=0;l<this.g.length;++l){c=this.b[l][v.a];if(!!c&&!!c.c&&!c.f&&c.i==1){i=jdb(c);i>u&&(u=i)}}this.m[v.a]=u}this.r=Ocb(this.m);Dcb(this);t=false}t&&Dcb(this);if(n){Ecb(this);Fcb(this);Jcb(this);for(l=0;l<this.b.length;++l){for(m=0;m<this.b[l].length;++m){c=this.b[l][m];!!c&&!!c.b&&(c.f||c.g)&&i$(this.d,c.b.p)}}}if((parseInt(this.a.nb[bzb])||0)!=o||(parseInt(this.a.nb[czb])||0)!=p){return false}else{return true}}
function Ycb(a,b){var c,d,e,f,g,h,i,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;this.p=true;this.d=b;if(G$(b,this,a,true)){this.p=false;return}u8(this.c,b);this.a.nb.style[Yyb]=qAb;v=Jdb(new Hdb,a[1][eSb]);w=fSb;(v.a&1)==1&&(w+=gSb);(v.a&2)==2&&(w+=hSb);(v.a&4)==4&&(w+=iSb);(v.a&8)==8&&(w+=jSb);this.i.className=w;this.k=(this.i.offsetHeight||0)-(parseInt(this.a.nb[bzb])||0);x=Yl((tl(),$doc),hxb);x.className=kSb+(Boolean(a[1][lSb])?mSb:nSb);x.style[Yyb]=uyb;x.style[$yb]=uyb;this.a.nb.appendChild(x);this.u=x.offsetWidth||0;this.v=x.offsetHeight||0;this.a.nb.removeChild(x);i=a[1][oSb];r=a[1][zHb];this.g=Yx(vF,263,-1,i,1);this.r=Yx(vF,263,-1,r,1);if(this.b==null){this.b=$x([NF,EF],[275,261],[46,37],[i,r],0,2,0)}else if(this.b.length!=i||this.b[0].length!=r){m=$x([NF,EF],[275,261],[46,37],[i,r],0,2,0);for(k=0;k<this.b.length;++k){for(l=0;l<this.b[k].length;++l){k<i&&l<r&&(m[k][l]=this.b[k][l])}}this.b=m}this.n=ktb(new gtb,this.w);d=v7(a[1],pSb);c=0;n=Hub(new Fub);p=Hub(new Fub);for(k=o3(new l3,a);y=k.b.length-2,y>k.a+1;){o=qy(q3(k));if(Qnb(qSb,o[0])){for(l=o3(new l3,o);z=l.b.length-2,z>l.a+1;){e=qy(q3(l));if(Qnb(rSb,e[0])){f=Gcb(this,e);if(f.c){q=ndb(f);f.a=d[c++];if(!q){hvb(new evb,f,n.a);++n.b}f.e>1?Mcb(this,f):q&&this.g[f.d]<kdb(f)&&(this.g[f.d]=kdb(f));if(f.f){hvb(new evb,f,p.a);++p.b}}}}}}Ccb(this);this.e=v7(a[1],sSb);this.q=v7(a[1],tSb);this.l=Ocb(this.g);Ecb(this);Lcb(n);Acb(this);Fcb(this);Kcb(n);for(g=Mub(p,0);g.b!=g.d.a;){f=py(Zub(g),37);u=f.b.p;h$(b,b.g[u.nb.tkPid]);hlb(f.b)}Jcb(this);for(t=(A=fpb(this.n).b.oc(),lrb(new jrb,A));t.a.Sb();){s=py((B=py(t.a.Tb(),51),B.yd()),36);h=py(this.w.qd(s),88);this.o.xd(s);this.w.xd(s);pN(h);F$(b,py(s,66))}this.n=null;this.p=false;this.t=false}
var iSb=' v-gridlayout-margin-bottom',jSb=' v-gridlayout-margin-left',hSb=' v-gridlayout-margin-right',gSb=' v-gridlayout-margin-top',uSb='AsyncLoader1',ASb='VGridLayout$1',vSb='VGridLayout$Cell',xSb='VGridLayout$Cell;',zSb='VGridLayout$SpanList',aSb='Widget must be a child of this panel.',BSb='WidgetMapImpl$2$1',wSb='[Lcom.vaadin.terminal.gwt.client.ui.',ySb='[[Lcom.vaadin.terminal.gwt.client.ui.',sSb='colExpand',rSb='gc',qSb='gr',nSb='off',tSb='rowExpand',$Rb='runCallbacks1',bSb='v-gridlayout',fSb='v-gridlayout-margin',kSb='v-gridlayout-spacing-',oSb='w',dSb='x',cSb='y';_=TG.prototype=new UG;_.gC=dH;_.Qb=hH;_.tI=0;_=wM.prototype;_.pc=iO;_=LU.prototype;_.pc=PU;_=R7.prototype=new nh;_.$c=T7;_.gC=U7;_.tI=142;_=wcb.prototype=new KS;_.Mc=Pcb;_.gC=Qcb;_.uc=Rcb;_.Nc=Scb;_.Oc=Tcb;_.Pc=Ucb;_.bc=Vcb;_.ec=Wcb;_.Qc=Xcb;_.Tc=Ycb;_.tI=168;_.b=null;_.d=null;_.e=null;_.g=null;_.h=null;_.k=0;_.l=null;_.m=null;_.n=null;_.p=false;_.q=null;_.r=null;_.t=false;_.u=0;_.v=0;_.x=null;_=Zcb.prototype=new N8;_.cd=adb;_.gC=bdb;_.bd=cdb;_.tI=169;_.a=null;_=ddb.prototype=new nh;_.gC=qdb;_.tI=170;_.a=0;_.b=null;_.c=null;_.d=0;_.e=1;_.f=false;_.g=false;_.h=0;_.i=1;_.k=null;_.l=false;_=rdb.prototype=new nh;_.gC=vdb;_.tI=171;_.b=0;var iA=gmb(YMb,uSb),AD=gmb(YOb,vSb),EF=fmb(wSb,xSb),NF=fmb(ySb,xSb),BD=gmb(YOb,zSb),zD=gmb(YOb,ASb),SC=gmb(_Pb,BSb);eH();