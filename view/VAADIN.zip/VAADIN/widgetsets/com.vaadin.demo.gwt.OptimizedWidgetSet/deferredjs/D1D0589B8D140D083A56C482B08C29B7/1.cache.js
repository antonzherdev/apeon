function NG(){}
function o7(){}
function Vbb(){}
function wcb(){}
function Ccb(){}
function Qcb(){}
function r7(){return MC}
function ZG(){return fA}
function ncb(){return wD}
function Acb(){return tD}
function Pcb(){return uD}
function Ucb(){return vD}
function ocb(){return this.k}
function q7(){return Ybb(new Vbb)}
function pcb(a){return this.p.pd(a)}
function ecb(a,b){return g3(a.e,a,b)}
function MN(a,b,c){IN(a,b,c)}
function HN(a,b,c,d){FN(a,b);a.qc(b,c,d)}
function ycb(a,b,c,d){a.b=d;a.h=b;a.c=c;return a}
function Bcb(a,b){return KM(this.b,a,b)}
function zcb(a){return ecb(this.b,a)}
function Tcb(a,b){a.b=dub(new bub);a.c=b;return a}
function Isb(a,b){Rob(a);Eob(a,b);return a}
function CN(a,b){a.E=dX(new bX,a);a.ob=b;return a}
function Icb(a){if(a.c){return a.c.s.Vc()+lkb(a.c)}else{return 0}}
function sN(a,b){if(b<0||b>a.E.d){throw smb(new qmb)}}
function FN(a,b){if(b.nb!=a){throw jmb(new gmb,iRb)}}
function EN(a,b,c,d){var e;TM(b);e=a.E.d;a.qc(b,c,d);uN(a,b,a.ob,e,true)}
function rN(a,b,c){var d;sN(a,c);if(b.nb==a){d=gX(a.E,b);d<c&&--c}return c}
function rU(a,b,c){b-=ln($doc);c-=mn($doc);IN(a,b,c)}
function Jcb(a){var b;if(a.c){b=a.c.s.Wc()+okb(a.c);return b}else{return 0}}
function Mcb(a){if(!a.d){return false}if(a.h){return false}else{Lcb(a);return true}}
function Fcb(a,b,c){a.l=c;a.i=b[1][kRb];a.e=b[1][lRb];Ncb(a,b);return a}
function mcb(a){var b;b=ly(this.p.rd(a),37);return a2(new Z1,Hcb(b)-okb(b.c),Gcb(b)-lkb(b.c))}
function Gcb(a){var b,c;b=a.l.s[a.i];for(c=1;c<a.k;++c){b+=a.l.w+a.l.s[a.i+c]}return b}
function Hcb(a){var b,c;c=a.l.h[a.e];for(b=1;b<a.f;++b){c+=a.l.v+a.l.h[a.e+b]}return c}
function icb(a){var b,c;for(c=iub(a,0);c.c!=c.e.b;){b=ly(vub(c),37);if(!b.g){Lcb(b);wub(c)}}}
function hcb(a){var b,c;for(c=iub(a,0);c.c!=c.e.b;){b=ly(vub(c),37);Lcb(b)}}
function Eob(a,b){var c,d;for(d=b.qd().pc();d.Tb();){c=ly(d.Ub(),51);a.xd(c.zd(),c.Ad())}}
function cqb(a,b){var c,d;for(c=0,d=a.c;c<d;++c){if(!b?irb(a,c)==null:(b==null?null:b)===vy(irb(a,c))){return c}}return -1}
function uN(a,b,c,d,e){d=rN(a,b,d);TM(b);hX(a.E,b,d);e?kL(c,b.ob,d):c.appendChild(b.ob);VM(b,a)}
function Kcb(a,b,c){if(!!a.c&&a.c.kb){HN(a.l.b,a.c,b,c);ukb(a.c,Hcb(a),Gcb(a));a.c.b=N7(new K7,a.b);Ckb(a.c,Hcb(a),Gcb(a))}}
function lcb(a){var b,c;b=Ux(pF,262,-1,a.length,1);for(c=0;c<b.length;++c){b[c]=a[c]}return b}
function qcb(a,b){var c;c=ly(this.x.yd(a),88);if(!c){return}Akb(c,b);this.x.xd(b,c);this.p.xd(ly(b,66),ly(this.p.rd(a),37))}
function ucb(a,b){var c;c=ly(this.x.rd(a),88);!!c&&Dkb(c,b,this.e);if(!this.q){Ocb(ly(this.p.rd(a),37),b);vrb(this.e.d,a)}}
function BN(a){CN(a,(Cl(),$doc).createElement(Tyb));a.ob.style[vyb]=Szb;a.ob.style[Mzb]=Fzb;return a}
function IN(a,b,c){var d;d=a.ob;if(b==-1&&c==-1){JN(d)}else{d.style[vyb]=Lzb;d.style[tyb]=b+fyb;d.style[uyb]=c+fyb}}
function dcb(a,b){var c,d,e;e=b[1][kRb];d=b[1][lRb];c=a.c[d][e];if(!c){c=Fcb(new Ccb,b,a);a.c[d][e]=c}else{Ncb(c,b)}return c}
function bH(){var a,c,d;while(SG){d=bi;SG=SG.b;!SG&&(TG=null);if(!d){(e7(),d7).xd(wD,new o7);XY()}else{try{(e7(),d7).xd(wD,new o7);XY()}catch(a){a=OF(a);if(oy(a,5)){c=a;h4.Jc(c)}else throw a}}}}
function Ocb(a,b){if(!!b&&!Boolean(b[1][SBb])){gyb in b[1]&&b[1][gyb].indexOf($Ab)!=-1?(a.g=true):(a.g=false);if(eyb in b[1]){a.m=a.h=b[1][eyb].indexOf($Ab)!=-1;gyb in b[1]&&(a.m=false)}else{a.m=!(gyb in b[1]);a.h=false}}}
function Zbb(a){var b,c,d;for(c=0;c<a.c.length;++c){for(d=0;d<a.c[c].length;++d){b=a.c[c][d];if(b){if(!!b.c&&b.m){b.c.ob.style[eyb]=Hcb(b)+fyb;Gkb(b.c)}b.k==1?!b.g&&a.s[d]<Icb(b)&&(a.s[d]=Icb(b)):kcb(a,b)}}}acb(a);a.n=lcb(a.s)}
function jcb(a,b){var c,d,e,f;c=null;for(e=iub(a.g,0);e.c!=e.e.b;){d=ly(vub(e),89);if(d.c<b.f){continue}else{c=d;break}}if(!c){c=Tcb(new Qcb,b.f);gub(a.g,c)}else if(c.c!=b.f){f=Tcb(new Qcb,b.f);hrb(a.g,cqb(a.g,c),f);c=f}eub(c.b,b)}
function kcb(a,b){var c,d,e,f;c=null;for(e=iub(a.t,0);e.c!=e.e.b;){d=ly(vub(e),89);if(d.c<b.k){continue}else{c=d;break}}if(!c){c=Tcb(new Qcb,b.k);gub(a.t,c)}else if(c.c!=b.k){f=Tcb(new Qcb,b.k);hrb(a.t,cqb(a.t,c),f);c=f}eub(c.b,b)}
function scb(a){var b,c,d,e;this.ob.style[gyb]=a;if(!nnb(a,this.i)){this.i=a;if(this.q){this.u=true}else{ccb(this);gcb(this);for(c=(d=Dob(this.p).c.pc(),Jqb(new Hqb,d));c.b.Tb();){b=ly((e=ly(c.b.Ub(),51),e.zd()),66);HZ(this.e,ly(b,36))}}}}
function Ybb(a){a.ob=(Cl(),$doc).createElement(Tyb);a.k=$doc.createElement(Tyb);a.b=BN(new $L);a.x=Gsb(new Esb);a.p=Gsb(new Esb);a.d=ycb(new wcb,a,ixb,a);a.g=dub(new bub);a.t=dub(new bub);a.ob.appendChild(a.k);a.ob[hyb]=jRb;rS(a,a.b);return a}
function $G(){VG=true;UG=(XG(),new NG);sj((pj(),oj),1);!!$stats&&$stats(Yj(gRb,uwb,null,null));UG.Rb();!!$stats&&$stats(Yj(gRb,hRb,null,null))}
function ccb(a){var b,c,d,e,f,g,h;if(!nnb(iwb,a.i)){h=a.n[0];for(g=1;g<a.n.length;++g){h+=a.w+a.n[g]}b=(parseInt(a.ob[jyb])||0)-a.l;f=b-h;d=0;if(f>0){for(g=0;g<a.s.length;++g){e=~~(f*a.r[g]/1000);a.s[g]=a.n[g]+e;d+=e}f-=d;c=0;while(f>0){++a.s[c%a.s.length];--f;++c}}}}
function bcb(a){var b,c,d,e,f,g,h;if(!nnb(iwb,a.y)){h=a.m[0];for(g=1;g<a.m.length;++g){h+=a.v+a.m[g]}a.b.ob.style[eyb]=iwb;b=parseInt(a.b.ob[kyb])||0;f=b-h;d=0;if(f>0){for(g=0;g<a.h.length;++g){e=~~(f*a.f[g]/1000);a.h[g]=a.m[g]+e;d+=e}f-=d;c=0;while(f>0){++a.h[c%a.h.length];--f;++c}}}}
function Wx(a,b,c,d,e,f,g){var h,i,k,l;k=d[e];i=e==f-1;l=Sx(i?g:0,k);by();ey(l,_x,ay);l.aC=a[e];l.tI=b[e];l.qI=c[e];if(!i){++e;for(h=0;h<k;++h){l[h]=Wx(a,b,c,d,e,f,g)}}return l}
function gcb(a){var b,c,d,e,f,g;f=0;g=0;for(d=0;d<a.c.length;++d){g=0;for(e=0;e<a.c[d].length;++e){c=a.c[d][e];!!c&&Kcb(c,f,g);g+=a.s[e]+a.w}f+=a.h[d]+a.v}nnb(iwb,a.y)?(a.b.ob.style[eyb]=f-a.v+fyb,undefined):(a.b.ob.style[eyb]=iwb,undefined);nnb(iwb,a.i)?(b=g-a.w):(b=(parseInt(a.ob[jyb])||0)-a.l);a.b.ob.style[gyb]=b+fyb}
function _bb(a){var b,c,d,e,f,g,h,i,k,l;for(h=iub(a.g,0);h.c!=h.e.b;){g=ly(vub(h),89);for(d=iub(g.b,0);d.c!=d.e.b;){c=ly(vub(d),37);l=c.h?0:Jcb(c);b=a.h[c.e];for(f=1;f<c.f;++f){b+=a.v+a.h[c.e+f]}if(b<l){i=l-b;k=~~(i/c.f);for(f=0;f<c.f;++f){e=c.e+f;a.h[e]+=k;i-=k}if(i>0){for(f=0;f<c.f;++f){e=c.e+f;a.h[e]+=1;i-=1;if(i==0){break}}}}}}}
function acb(a){var b,c,d,e,f,g,h,i,k,l;for(h=iub(a.t,0);h.c!=h.e.b;){g=ly(vub(h),89);for(d=iub(g.b,0);d.c!=d.e.b;){c=ly(vub(d),37);e=c.g?0:Icb(c);b=a.s[c.i];for(f=1;f<c.k;++f){b+=a.w+a.s[c.i+f]}if(b<e){i=e-b;l=~~(i/c.k);for(f=0;f<c.k;++f){k=c.i+f;a.s[k]+=l;i-=l}if(i>0){for(f=0;f<c.k;++f){k=c.i+f;a.s[k]+=1;i-=1;if(i==0){break}}}}}}}
function Lcb(a){var b;b=CZ(a.l.e,a.d);if(!a.c||a.c.q!=b){if(a.l.x.pd(b)){a.c=ly(a.l.x.rd(b),88);a.c.ob.style[eyb]=iwb;a.c.ob.style[gyb]=iwb}else{a.c=dkb(new akb,ly(b,36),0);a.l.x.xd(ly(b,36),a.c);a.c.ob.style[eyb]=iwb;EN(a.l.b,a.c,0,0)}a.l.p.xd(b,a)}rkb(a.c,a.d,a.l.e,-1);a.l.u&&(a3(),Boolean(a.d[1][SBb]))&&HZ(a.l.e,a.c.q);Gkb(a.c);a.l.o.yd(b)}
function Ncb(a,b){var c,d,e;a.f=wRb in b[1]?b[1][wRb]:1;a.k=HGb in b[1]?b[1][HGb]:1;for(c=0;c<a.f;++c){for(d=0;d<a.k;++d){(c>0||d>0)&&Zx(a.l.c[a.e+c],a.i+d,null)}}b=b[2];if(a.d){if(!b){a.c=null}else if(!!a.c&&a.c.q!=CZ(a.l.e,b)){a.c=null;e=CZ(a.l.e,b);if(a.l.x.pd(e)){a.c=ly(a.l.x.rd(e),88);a.c.ob.style[eyb]=iwb;a.c.ob.style[gyb]=iwb;a.l.p.xd(e,a)}}}a.d=b;Ocb(a,b)}
function tcb(a){var b,c,d,e,f,g,h,i,k,l,m,n,o,p,q,r,s,t,u,v;this.ob.style[eyb]=a;if(!nnb(a,this.y)){this.y=a;if(this.q){this.u=true}else{o=lcb(this.h);bcb(this);h=false;g=null;for(i=0;i<o.length;++i){if(this.h[i]!=o[i]){f=this.c[i];for(k=0;k<f.length;++k){b=f[k];if(!!b&&!!b.c&&b.m){ukb(b.c,Hcb(b),Gcb(b));HZ(this.e,b.c.q);Gkb(b.c);l=Icb(b);if(this.h[i]<o[i]&&l>this.n[k]&&b.k==1){this.n[k]=l;if(l>this.s[k]){this.s[k]=l;h=true}}else if(l<this.n[k]){!g&&(g=Osb(new Msb));Rsb(g,Gmb(k))}}}}}if(g){r=false;for(q=(s=Dob(g.b).c.pc(),Jqb(new Hqb,s));q.b.Tb();){p=ly((t=ly(q.b.Ub(),51),t.zd()),43);n=this.n[p.b];m=0;for(e=0;e<this.h.length;++e){d=this.c[e][p.b];!!d&&!d.g&&Icb(d)>m&&(m=Icb(d))}if(m<n){this.n[p.b]=this.s[p.b]=m;r=true}}if(r){acb(this);this.n=lcb(this.s);h=true}}gcb(this);for(c=(u=Dob(this.p).c.pc(),Jqb(new Hqb,u));c.b.Tb();){b=ly((v=ly(c.b.Ub(),51),v.zd()),66);HZ(this.e,ly(b,36))}h&&nnb(iwb,this.i)&&n3(this,false)}}}
function rcb(a){var b,c,d,e,f,g,h,i,k,l,m,n,o,p,q,r,s,t,u,v,w,x;n=false;s=false;t=false;o=parseInt(this.b.ob[jyb])||0;p=parseInt(this.b.ob[kyb])||0;(nnb(iwb,this.y)||nnb(iwb,this.i))&&(n=true);g=srb(new prb);h=srb(new prb);for(r=a.pc();r.Tb();){q=ly(r.Ub(),66);c=ly(this.p.rd(q),37);if(!c.g||!c.h){c.c.ob.style[eyb]=iwb;c.c.ob.style[gyb]=iwb;Gkb(c.c);Ekb(c.c);x=Jcb(c);b=this.h[c.e];for(l=1;l<c.f;++l){b+=this.v+this.h[c.e+l]}if(b<x){n=true;c.f==1?(this.h[c.e]=this.m[c.e]=x):(s=true)}else b!=x&&vrb(g,Gmb(c.e));k=Icb(c);b=this.s[c.i];for(l=1;l<c.k;++l){b+=this.w+this.s[c.i+l]}if(b<k){n=true;c.k==1?(this.s[c.i]=this.n[c.i]=k):(t=true)}else b!=k&&vrb(h,Gmb(c.i))}}if(g.c>0){for(e=qqb(new nqb,g);e.b<e.d.md();){d=ly(sqb(e),43);f=0;for(l=0;l<this.s.length;++l){c=this.c[d.b][l];if(!!c&&!!c.d&&!c.h&&c.f==1){x=Jcb(c);x>f&&(f=x)}}this.m[d.b]=f}n=true;this.h=lcb(this.m);_bb(this);s=false}s&&_bb(this);if(h.c>0){n=true;for(w=qqb(new nqb,h);w.b<w.d.md();){v=ly(sqb(w),43);u=this.n[v.b]=0;for(l=0;l<this.h.length;++l){c=this.c[l][v.b];if(!!c&&!!c.d&&!c.g&&c.k==1){i=Icb(c);i>u&&(u=i)}}this.n[v.b]=u}this.s=lcb(this.n);acb(this);t=false}t&&acb(this);if(n){bcb(this);ccb(this);gcb(this);for(l=0;l<this.c.length;++l){for(m=0;m<this.c[l].length;++m){c=this.c[l][m];!!c&&!!c.c&&(c.g||c.h)&&HZ(this.e,c.c.q)}}}if((parseInt(this.b.ob[jyb])||0)!=o||(parseInt(this.b.ob[kyb])||0)!=p){return false}else{return true}}
function vcb(a,b){var c,d,e,f,g,h,i,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;this.q=true;this.e=b;if(d$(b,this,a,true)){this.q=false;return}T7(this.d,b);this.b.ob.style[eyb]=yzb;v=gdb(new edb,a[1][mRb]);w=nRb;(v.b&1)==1&&(w+=oRb);(v.b&2)==2&&(w+=pRb);(v.b&4)==4&&(w+=qRb);(v.b&8)==8&&(w+=rRb);this.k.className=w;this.l=(this.k.offsetHeight||0)-(parseInt(this.b.ob[jyb])||0);x=(Cl(),$doc).createElement(Tyb);x.className=sRb+(Boolean(a[1][tRb])?uRb:vRb);x.style[eyb]=Qxb;x.style[gyb]=Qxb;this.b.ob.appendChild(x);this.v=x.offsetWidth||0;this.w=x.offsetHeight||0;this.b.ob.removeChild(x);i=a[1][wRb];r=a[1][HGb];this.h=Ux(pF,262,-1,i,1);this.s=Ux(pF,262,-1,r,1);if(this.c==null){this.c=Wx([HF,yF],[274,260],[46,37],[i,r],0,2,0)}else if(this.c.length!=i||this.c[0].length!=r){m=Wx([HF,yF],[274,260],[46,37],[i,r],0,2,0);for(k=0;k<this.c.length;++k){for(l=0;l<this.c[k].length;++l){k<i&&l<r&&(m[k][l]=this.c[k][l])}}this.c=m}this.o=Isb(new Esb,this.x);d=U6(a[1],xRb);c=0;n=dub(new bub);p=dub(new bub);for(k=N2(new K2,a);y=k.c.length-2,y>k.b+1;){o=my(P2(k));if(nnb(yRb,o[0])){for(l=N2(new K2,o);z=l.c.length-2,z>l.b+1;){e=my(P2(l));if(nnb(zRb,e[0])){f=dcb(this,e);if(f.d){q=Mcb(f);f.b=d[c++];if(!q){Fub(new Cub,f,n.b);++n.c}f.f>1?jcb(this,f):q&&this.h[f.e]<Jcb(f)&&(this.h[f.e]=Jcb(f));if(f.g){Fub(new Cub,f,p.b);++p.c}}}}}}_bb(this);this.f=U6(a[1],ARb);this.r=U6(a[1],BRb);this.m=lcb(this.h);bcb(this);icb(n);Zbb(this);ccb(this);hcb(n);for(g=iub(p,0);g.c!=g.e.b;){f=ly(vub(g),37);u=f.c.q;GZ(b,b.h[u.ob.tkPid]);Gkb(f.c)}gcb(this);for(t=(A=Dob(this.o).c.pc(),Jqb(new Hqb,A));t.b.Tb();){s=ly((B=ly(t.b.Ub(),51),B.zd()),36);h=ly(this.x.rd(s),88);this.p.yd(s);this.x.yd(s);TM(h);c$(b,ly(s,66))}this.o=null;this.q=false;this.u=false}
var qRb=' v-gridlayout-margin-bottom',rRb=' v-gridlayout-margin-left',pRb=' v-gridlayout-margin-right',oRb=' v-gridlayout-margin-top',CRb='AsyncLoader1',IRb='VGridLayout$1',DRb='VGridLayout$Cell',FRb='VGridLayout$Cell;',HRb='VGridLayout$SpanList',iRb='Widget must be a child of this panel.',JRb='WidgetMapImpl$2$1',ERb='[Lcom.vaadin.terminal.gwt.client.ui.',GRb='[[Lcom.vaadin.terminal.gwt.client.ui.',ARb='colExpand',zRb='gc',yRb='gr',vRb='off',uRb='on',BRb='rowExpand',gRb='runCallbacks1',jRb='v-gridlayout',nRb='v-gridlayout-margin',sRb='v-gridlayout-spacing-',wRb='w',lRb='x',kRb='y';_=NG.prototype=new OG;_.gC=ZG;_.Rb=bH;_.tI=0;_=$L.prototype;_.qc=MN;_=nU.prototype;_.qc=rU;_=o7.prototype=new lh;_._c=q7;_.gC=r7;_.tI=141;_=Vbb.prototype=new mS;_.Nc=mcb;_.gC=ncb;_.vc=ocb;_.Oc=pcb;_.Pc=qcb;_.Qc=rcb;_.cc=scb;_.fc=tcb;_.Rc=ucb;_.Uc=vcb;_.tI=167;_.c=null;_.e=null;_.f=null;_.h=null;_.i=null;_.l=0;_.m=null;_.n=null;_.o=null;_.q=false;_.r=null;_.s=null;_.u=false;_.v=0;_.w=0;_.y=null;_=wcb.prototype=new k8;_.dd=zcb;_.gC=Acb;_.cd=Bcb;_.tI=168;_.b=null;_=Ccb.prototype=new lh;_.gC=Pcb;_.tI=169;_.b=0;_.c=null;_.d=null;_.e=0;_.f=1;_.g=false;_.h=false;_.i=0;_.k=1;_.l=null;_.m=false;_=Qcb.prototype=new lh;_.gC=Ucb;_.tI=170;_.c=0;var fA=Flb(hMb,CRb),uD=Flb(eOb,DRb),yF=Elb(ERb,FRb),HF=Elb(GRb,FRb),vD=Flb(eOb,HRb),tD=Flb(eOb,IRb),MC=Flb(hPb,JRb);$G();