function DH(){}
function L8(){}
function qdb(){}
function Tdb(){}
function Zdb(){}
function leb(){}
function O8(){return BD}
function PH(){return SA}
function Kdb(){return lE}
function Xdb(){return iE}
function keb(){return jE}
function peb(){return kE}
function Ldb(){return this.k}
function N8(){return tdb(new qdb)}
function Mdb(a){return this.p.od(a)}
function Bdb(a,b){return C4(a.e,a,b)}
function HO(a,b,c){DO(a,b,c)}
function CO(a,b,c,d){AO(a,b);a.pc(b,c,d)}
function Vdb(a,b,c,d){a.b=d;a.h=b;a.c=c;return a}
function Ydb(a,b){return FN(this.b,a,b)}
function Wdb(a){return Bdb(this.b,a)}
function oeb(a,b){a.b=Avb(new yvb);a.c=b;return a}
function dub(a,b){mqb(a);_pb(a,b);return a}
function xO(a,b){a.E=fY(new dY,a);a.ob=b;return a}
function deb(a){if(a.c){return a.c.s.Uc()+Ilb(a.c)}else{return 0}}
function nO(a,b){if(b<0||b>a.E.d){throw Pnb(new Nnb)}}
function AO(a,b){if(b.nb!=a){throw Gnb(new Dnb,WSb)}}
function mO(a,b,c){var d;nO(a,c);if(b.nb==a){d=iY(a.E,b);d<c&&--c}return c}
function zO(a,b,c,d){var e;ON(b);e=a.E.d;a.pc(b,c,d);pO(a,b,a.ob,e,true)}
function tV(a,b,c){b-=un($doc);c-=vn($doc);DO(a,b,c)}
function Edb(a){var b,c;for(c=Fvb(a,0);c.c!=c.e.b;){b=Ty(Svb(c),38);geb(b)}}
function Fdb(a){var b,c;for(c=Fvb(a,0);c.c!=c.e.b;){b=Ty(Svb(c),38);if(!b.g){geb(b);Tvb(c)}}}
function eeb(a){var b;if(a.c){b=a.c.s.Vc()+Llb(a.c);return b}else{return 0}}
function heb(a){if(!a.d){return false}if(a.h){return false}else{geb(a);return true}}
function aeb(a,b,c){a.l=c;a.i=b[1][YSb];a.e=b[1][ZSb];ieb(a,b);return a}
function DO(a,b,c){var d;d=a.ob;if(b==-1&&c==-1){EO(d)}else{d.style[Wzb]=lBb;d.style[Uzb]=b+Gzb;d.style[Vzb]=c+Gzb}}
function _pb(a,b){var c,d;for(d=b.pd().oc();d.Sb();){c=Ty(d.Tb(),52);a.wd(c.yd(),c.zd())}}
function zrb(a,b){var c,d;for(c=0,d=a.c;c<d;++c){if(!b?Fsb(a,c)==null:(b==null?null:b)===bz(Fsb(a,c))){return c}}return -1}
function ceb(a){var b,c;c=a.l.h[a.e];for(b=1;b<a.f;++b){c+=a.l.v+a.l.h[a.e+b]}return c}
function beb(a){var b,c;b=a.l.s[a.i];for(c=1;c<a.k;++c){b+=a.l.w+a.l.s[a.i+c]}return b}
function Idb(a){var b,c;b=Ay(eG,270,-1,a.length,1);for(c=0;c<b.length;++c){b[c]=a[c]}return b}
function Ndb(a,b){var c;c=Ty(this.x.xd(a),89);if(!c){return}Xlb(c,b);this.x.wd(b,c);this.p.wd(Ty(b,67),Ty(this.p.qd(a),38))}
function Jdb(a){var b;b=Ty(this.p.qd(a),38);return w3(new t3,ceb(b)-Llb(b.c),beb(b)-Ilb(b.c))}
function Rdb(a,b){var c;c=Ty(this.x.qd(a),89);!!c&&$lb(c,b,this.e);if(!this.q){jeb(Ty(this.p.qd(a),38),b);Ssb(this.e.d,a)}}
function pO(a,b,c,d,e){d=mO(a,b,d);ON(b);jY(a.E,b,d);e?$L(c,b.ob,d):c.appendChild(b.ob);QN(b,a)}
function feb(a,b,c){if(!!a.c&&a.c.kb){CO(a.l.b,a.c,b,c);Rlb(a.c,ceb(a),beb(a));a.c.b=i9(new f9,a.b);Zlb(a.c,ceb(a),beb(a))}}
function wO(a){xO(a,(Hl(),$doc).createElement(uAb));a.ob.style[Wzb]=sBb;a.ob.style[mBb]=fBb;return a}
function QH(){LH=true;KH=(NH(),new DH);Cj((zj(),yj),1);!!$stats&&$stats(gk(USb,Rxb,null,null));KH.Qb();!!$stats&&$stats(gk(USb,VSb,null,null))}
function tdb(a){a.ob=(Hl(),$doc).createElement(uAb);a.k=$doc.createElement(uAb);a.b=wO(new VM);a.x=bub(new _tb);a.p=bub(new _tb);a.d=Vdb(new Tdb,a,Hyb,a);a.g=Avb(new yvb);a.t=Avb(new yvb);a.ob.appendChild(a.k);a.ob[Izb]=XSb;dR(a,a.b);return a}
function Adb(a,b){var c,d,e;e=b[1][YSb];d=b[1][ZSb];c=a.c[d][e];if(!c){c=aeb(new Zdb,b,a);a.c[d][e]=c}else{ieb(c,b)}return c}
function TH(){var a,c,d;while(IH){d=li;IH=IH.b;!IH&&(JH=null);if(!d){(B8(),A8).wd(lE,new L8);r$()}else{try{(B8(),A8).wd(lE,new L8);r$()}catch(a){a=EG(a);if(Wy(a,5)){c=a;D5.Ic(c)}else throw a}}}}
function Ddb(a){var b,c,d,e,f,g;f=0;g=0;for(d=0;d<a.c.length;++d){g=0;for(e=0;e<a.c[d].length;++e){c=a.c[d][e];!!c&&feb(c,f,g);g+=a.s[e]+a.w}f+=a.h[d]+a.v}Kob(Fxb,a.y)?(a.b.ob.style[Fzb]=f-a.v+Gzb,undefined):(a.b.ob.style[Fzb]=Fxb,undefined);Kob(Fxb,a.i)?(b=g-a.w):(b=(parseInt(a.ob[Kzb])||0)-a.l);a.b.ob.style[Hzb]=b+Gzb}
function Cy(a,b,c,d,e,f,g){var h,i,k,l;k=d[e];i=e==f-1;l=yy(i?g:0,k);Jy();My(l,Hy,Iy);l.aC=a[e];l.tI=b[e];l.qI=c[e];if(!i){++e;for(h=0;h<k;++h){l[h]=Cy(a,b,c,d,e,f,g)}}return l}
function ydb(a){var b,c,d,e,f,g,h;if(!Kob(Fxb,a.y)){h=a.m[0];for(g=1;g<a.m.length;++g){h+=a.v+a.m[g]}a.b.ob.style[Fzb]=Fxb;b=parseInt(a.b.ob[Lzb])||0;f=b-h;d=0;if(f>0){for(g=0;g<a.h.length;++g){e=~~(f*a.f[g]/1000);a.h[g]=a.m[g]+e;d+=e}f-=d;c=0;while(f>0){++a.h[c%a.h.length];--f;++c}}}}
function jeb(a,b){if(!!b&&!Boolean(b[1][yDb])){Hzb in b[1]&&b[1][Hzb].indexOf(GCb)!=-1?(a.g=true):(a.g=false);if(Fzb in b[1]){a.m=a.h=b[1][Fzb].indexOf(GCb)!=-1;Hzb in b[1]&&(a.m=false)}else{a.m=!(Hzb in b[1]);a.h=false}}}
function udb(a){var b,c,d;for(c=0;c<a.c.length;++c){for(d=0;d<a.c[c].length;++d){b=a.c[c][d];if(b){if(!!b.c&&b.m){b.c.ob.style[Fzb]=ceb(b)+Gzb;bmb(b.c)}b.k==1?!b.g&&a.s[d]<deb(b)&&(a.s[d]=deb(b)):Hdb(a,b)}}}xdb(a);a.n=Idb(a.s)}
function Gdb(a,b){var c,d,e,f;c=null;for(e=Fvb(a.g,0);e.c!=e.e.b;){d=Ty(Svb(e),90);if(d.c<b.f){continue}else{c=d;break}}if(!c){c=oeb(new leb,b.f);Dvb(a.g,c)}else if(c.c!=b.f){f=oeb(new leb,b.f);Esb(a.g,zrb(a.g,c),f);c=f}Bvb(c.b,b)}
function Hdb(a,b){var c,d,e,f;c=null;for(e=Fvb(a.t,0);e.c!=e.e.b;){d=Ty(Svb(e),90);if(d.c<b.k){continue}else{c=d;break}}if(!c){c=oeb(new leb,b.k);Dvb(a.t,c)}else if(c.c!=b.k){f=oeb(new leb,b.k);Esb(a.t,zrb(a.t,c),f);c=f}Bvb(c.b,b)}
function Pdb(a){var b,c,d,e;this.ob.style[Hzb]=a;if(!Kob(a,this.i)){this.i=a;if(this.q){this.u=true}else{zdb(this);Ddb(this);for(c=(d=$pb(this.p).c.oc(),esb(new csb,d));c.b.Sb();){b=Ty((e=Ty(c.b.Tb(),52),e.yd()),67);b_(this.e,Ty(b,37))}}}}
function zdb(a){var b,c,d,e,f,g,h;if(!Kob(Fxb,a.i)){h=a.n[0];for(g=1;g<a.n.length;++g){h+=a.w+a.n[g]}b=(parseInt(a.ob[Kzb])||0)-a.l;f=b-h;d=0;if(f>0){for(g=0;g<a.s.length;++g){e=~~(f*a.r[g]/1000);a.s[g]=a.n[g]+e;d+=e}f-=d;c=0;while(f>0){++a.s[c%a.s.length];--f;++c}}}}
function wdb(a){var b,c,d,e,f,g,h,i,k,l;for(h=Fvb(a.g,0);h.c!=h.e.b;){g=Ty(Svb(h),90);for(d=Fvb(g.b,0);d.c!=d.e.b;){c=Ty(Svb(d),38);l=c.h?0:eeb(c);b=a.h[c.e];for(f=1;f<c.f;++f){b+=a.v+a.h[c.e+f]}if(b<l){i=l-b;k=~~(i/c.f);for(f=0;f<c.f;++f){e=c.e+f;a.h[e]+=k;i-=k}if(i>0){for(f=0;f<c.f;++f){e=c.e+f;a.h[e]+=1;i-=1;if(i==0){break}}}}}}}
function xdb(a){var b,c,d,e,f,g,h,i,k,l;for(h=Fvb(a.t,0);h.c!=h.e.b;){g=Ty(Svb(h),90);for(d=Fvb(g.b,0);d.c!=d.e.b;){c=Ty(Svb(d),38);e=c.g?0:deb(c);b=a.s[c.i];for(f=1;f<c.k;++f){b+=a.w+a.s[c.i+f]}if(b<e){i=e-b;l=~~(i/c.k);for(f=0;f<c.k;++f){k=c.i+f;a.s[k]+=l;i-=l}if(i>0){for(f=0;f<c.k;++f){k=c.i+f;a.s[k]+=1;i-=1;if(i==0){break}}}}}}}
function geb(a){var b;b=Y$(a.l.e,a.d);if(!a.c||a.c.q!=b){if(a.l.x.od(b)){a.c=Ty(a.l.x.qd(b),89);a.c.ob.style[Fzb]=Fxb;a.c.ob.style[Hzb]=Fxb}else{a.c=Alb(new xlb,Ty(b,37),0);a.l.x.wd(Ty(b,37),a.c);a.c.ob.style[Fzb]=Fxb;zO(a.l.b,a.c,0,0)}a.l.p.wd(b,a)}Olb(a.c,a.d,a.l.e,-1);a.l.u&&(w4(),Boolean(a.d[1][yDb]))&&b_(a.l.e,a.c.q);bmb(a.c);a.l.o.xd(b)}
function ieb(a,b){var c,d,e;a.f=iTb in b[1]?b[1][iTb]:1;a.k=mIb in b[1]?b[1][mIb]:1;for(c=0;c<a.f;++c){for(d=0;d<a.k;++d){(c>0||d>0)&&Fy(a.l.c[a.e+c],a.i+d,null)}}b=b[2];if(a.d){if(!b){a.c=null}else if(!!a.c&&a.c.q!=Y$(a.l.e,b)){a.c=null;e=Y$(a.l.e,b);if(a.l.x.od(e)){a.c=Ty(a.l.x.qd(e),89);a.c.ob.style[Fzb]=Fxb;a.c.ob.style[Hzb]=Fxb;a.l.p.wd(e,a)}}}a.d=b;jeb(a,b)}
function Qdb(a){var b,c,d,e,f,g,h,i,k,l,m,n,o,p,q,r,s,t,u,v;this.ob.style[Fzb]=a;if(!Kob(a,this.y)){this.y=a;if(this.q){this.u=true}else{o=Idb(this.h);ydb(this);h=false;g=null;for(i=0;i<o.length;++i){if(this.h[i]!=o[i]){f=this.c[i];for(k=0;k<f.length;++k){b=f[k];if(!!b&&!!b.c&&b.m){Rlb(b.c,ceb(b),beb(b));b_(this.e,b.c.q);bmb(b.c);l=deb(b);if(this.h[i]<o[i]&&l>this.n[k]&&b.k==1){this.n[k]=l;if(l>this.s[k]){this.s[k]=l;h=true}}else if(l<this.n[k]){!g&&(g=jub(new hub));mub(g,bob(k))}}}}}if(g){r=false;for(q=(s=$pb(g.b).c.oc(),esb(new csb,s));q.b.Sb();){p=Ty((t=Ty(q.b.Tb(),52),t.yd()),44);n=this.n[p.b];m=0;for(e=0;e<this.h.length;++e){d=this.c[e][p.b];!!d&&!d.g&&deb(d)>m&&(m=deb(d))}if(m<n){this.n[p.b]=this.s[p.b]=m;r=true}}if(r){xdb(this);this.n=Idb(this.s);h=true}}Ddb(this);for(c=(u=$pb(this.p).c.oc(),esb(new csb,u));c.b.Sb();){b=Ty((v=Ty(c.b.Tb(),52),v.yd()),67);b_(this.e,Ty(b,37))}h&&Kob(Fxb,this.i)&&J4(this,false)}}}
function Odb(a){var b,c,d,e,f,g,h,i,k,l,m,n,o,p,q,r,s,t,u,v,w,x;n=false;s=false;t=false;o=parseInt(this.b.ob[Kzb])||0;p=parseInt(this.b.ob[Lzb])||0;(Kob(Fxb,this.y)||Kob(Fxb,this.i))&&(n=true);g=Psb(new Msb);h=Psb(new Msb);for(r=a.oc();r.Sb();){q=Ty(r.Tb(),67);c=Ty(this.p.qd(q),38);if(!c.g||!c.h){c.c.ob.style[Fzb]=Fxb;c.c.ob.style[Hzb]=Fxb;bmb(c.c);_lb(c.c);x=eeb(c);b=this.h[c.e];for(l=1;l<c.f;++l){b+=this.v+this.h[c.e+l]}if(b<x){n=true;c.f==1?(this.h[c.e]=this.m[c.e]=x):(s=true)}else b!=x&&Ssb(g,bob(c.e));k=deb(c);b=this.s[c.i];for(l=1;l<c.k;++l){b+=this.w+this.s[c.i+l]}if(b<k){n=true;c.k==1?(this.s[c.i]=this.n[c.i]=k):(t=true)}else b!=k&&Ssb(h,bob(c.i))}}if(g.c>0){for(e=Nrb(new Krb,g);e.b<e.d.ld();){d=Ty(Prb(e),44);f=0;for(l=0;l<this.s.length;++l){c=this.c[d.b][l];if(!!c&&!!c.d&&!c.h&&c.f==1){x=eeb(c);x>f&&(f=x)}}this.m[d.b]=f}n=true;this.h=Idb(this.m);wdb(this);s=false}s&&wdb(this);if(h.c>0){n=true;for(w=Nrb(new Krb,h);w.b<w.d.ld();){v=Ty(Prb(w),44);u=this.n[v.b]=0;for(l=0;l<this.h.length;++l){c=this.c[l][v.b];if(!!c&&!!c.d&&!c.g&&c.k==1){i=deb(c);i>u&&(u=i)}}this.n[v.b]=u}this.s=Idb(this.n);xdb(this);t=false}t&&xdb(this);if(n){ydb(this);zdb(this);Ddb(this);for(l=0;l<this.c.length;++l){for(m=0;m<this.c[l].length;++m){c=this.c[l][m];!!c&&!!c.c&&(c.g||c.h)&&b_(this.e,c.c.q)}}}if((parseInt(this.b.ob[Kzb])||0)!=o||(parseInt(this.b.ob[Lzb])||0)!=p){return false}else{return true}}
function Sdb(a,b){var c,d,e,f,g,h,i,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;this.q=true;this.e=b;if(z_(b,this,a,true)){this.q=false;return}o9(this.d,b);this.b.ob.style[Fzb]=_Ab;v=Deb(new Beb,a[1][$Sb]);w=_Sb;(v.b&1)==1&&(w+=aTb);(v.b&2)==2&&(w+=bTb);(v.b&4)==4&&(w+=cTb);(v.b&8)==8&&(w+=dTb);this.k.className=w;this.l=(this.k.offsetHeight||0)-(parseInt(this.b.ob[Kzb])||0);x=(Hl(),$doc).createElement(uAb);x.className=eTb+(Boolean(a[1][fTb])?gTb:hTb);x.style[Fzb]=nzb;x.style[Hzb]=nzb;this.b.ob.appendChild(x);this.v=x.offsetWidth||0;this.w=x.offsetHeight||0;this.b.ob.removeChild(x);i=a[1][iTb];r=a[1][mIb];this.h=Ay(eG,270,-1,i,1);this.s=Ay(eG,270,-1,r,1);if(this.c==null){this.c=Cy([xG,oG],[282,268],[47,38],[i,r],0,2,0)}else if(this.c.length!=i||this.c[0].length!=r){m=Cy([xG,oG],[282,268],[47,38],[i,r],0,2,0);for(k=0;k<this.c.length;++k){for(l=0;l<this.c[k].length;++l){k<i&&l<r&&(m[k][l]=this.c[k][l])}}this.c=m}this.o=dub(new _tb,this.x);d=p8(a[1],jTb);c=0;n=Avb(new yvb);p=Avb(new yvb);for(k=h4(new e4,a);y=k.c.length-2,y>k.b+1;){o=Uy(j4(k));if(Kob(kTb,o[0])){for(l=h4(new e4,o);z=l.c.length-2,z>l.b+1;){e=Uy(j4(l));if(Kob(lTb,e[0])){f=Adb(this,e);if(f.d){q=heb(f);f.b=d[c++];if(!q){awb(new Zvb,f,n.b);++n.c}f.f>1?Gdb(this,f):q&&this.h[f.e]<eeb(f)&&(this.h[f.e]=eeb(f));if(f.g){awb(new Zvb,f,p.b);++p.c}}}}}}wdb(this);this.f=p8(a[1],mTb);this.r=p8(a[1],nTb);this.m=Idb(this.h);ydb(this);Fdb(n);udb(this);zdb(this);Edb(n);for(g=Fvb(p,0);g.c!=g.e.b;){f=Ty(Svb(g),38);u=f.c.q;a_(b,b.h[u.ob.tkPid]);bmb(f.c)}Ddb(this);for(t=(A=$pb(this.o).c.oc(),esb(new csb,A));t.b.Sb();){s=Ty((B=Ty(t.b.Tb(),52),B.yd()),37);h=Ty(this.x.qd(s),89);this.p.xd(s);this.x.xd(s);ON(h);y_(b,Ty(s,67))}this.o=null;this.q=false;this.u=false}
var cTb=' v-gridlayout-margin-bottom',dTb=' v-gridlayout-margin-left',bTb=' v-gridlayout-margin-right',aTb=' v-gridlayout-margin-top',oTb='AsyncLoader1',uTb='VGridLayout$1',pTb='VGridLayout$Cell',rTb='VGridLayout$Cell;',tTb='VGridLayout$SpanList',WSb='Widget must be a child of this panel.',vTb='WidgetMapImpl$2$1',qTb='[Lcom.vaadin.terminal.gwt.client.ui.',sTb='[[Lcom.vaadin.terminal.gwt.client.ui.',mTb='colExpand',lTb='gc',kTb='gr',hTb='off',gTb='on',nTb='rowExpand',USb='runCallbacks1',XSb='v-gridlayout',_Sb='v-gridlayout-margin',eTb='v-gridlayout-spacing-',iTb='w',ZSb='x',YSb='y';_=DH.prototype=new EH;_.gC=PH;_.Qb=TH;_.tI=0;_=VM.prototype;_.pc=HO;_=pV.prototype;_.pc=tV;_=L8.prototype=new vh;_.$c=N8;_.gC=O8;_.tI=148;_=qdb.prototype=new $Q;_.Mc=Jdb;_.gC=Kdb;_.uc=Ldb;_.Nc=Mdb;_.Oc=Ndb;_.Pc=Odb;_.bc=Pdb;_.ec=Qdb;_.Qc=Rdb;_.Tc=Sdb;_.tI=174;_.c=null;_.e=null;_.f=null;_.h=null;_.i=null;_.l=0;_.m=null;_.n=null;_.o=null;_.q=false;_.r=null;_.s=null;_.u=false;_.v=0;_.w=0;_.y=null;_=Tdb.prototype=new H9;_.cd=Wdb;_.gC=Xdb;_.bd=Ydb;_.tI=175;_.b=null;_=Zdb.prototype=new vh;_.gC=keb;_.tI=176;_.b=0;_.c=null;_.d=null;_.e=0;_.f=1;_.g=false;_.h=false;_.i=0;_.k=1;_.l=null;_.m=false;_=leb.prototype=new vh;_.gC=peb;_.tI=177;_.c=0;var SA=anb(RNb,oTb),jE=anb(SPb,pTb),oG=_mb(qTb,rTb),xG=_mb(sTb,rTb),kE=anb(SPb,tTb),iE=anb(SPb,uTb),BD=anb(VQb,vTb);QH();