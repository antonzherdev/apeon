function NH(){}
function V8(){}
function Adb(){}
function beb(){}
function heb(){}
function veb(){}
function Y8(){return LD}
function ZH(){return aB}
function Udb(){return vE}
function feb(){return sE}
function ueb(){return tE}
function zeb(){return uE}
function Vdb(){return this.k}
function X8(){return Ddb(new Adb)}
function Wdb(a){return this.p.rd(a)}
function Ldb(a,b){return M4(a.e,a,b)}
function RO(a,b,c){NO(a,b,c)}
function MO(a,b,c,d){KO(a,b);a.sc(b,c,d)}
function deb(a,b,c,d){a.b=d;a.h=b;a.c=c;return a}
function geb(a,b){return PN(this.b,a,b)}
function eeb(a){return Ldb(this.b,a)}
function yeb(a,b){a.b=Kvb(new Ivb);a.c=b;return a}
function nub(a,b){wqb(a);jqb(a,b);return a}
function HO(a,b){a.G=pY(new nY,a);a.qb=b;return a}
function neb(a){if(a.c){return a.c.s.Xc()+Slb(a.c)}else{return 0}}
function xO(a,b){if(b<0||b>a.G.d){throw Znb(new Xnb)}}
function KO(a,b){if(b.pb!=a){throw Qnb(new Nnb,hTb)}}
function JO(a,b,c,d){var e;YN(b);e=a.G.d;a.sc(b,c,d);zO(a,b,a.qb,e,true)}
function wO(a,b,c){var d;xO(a,c);if(b.pb==a){d=sY(a.G,b);d<c&&--c}return c}
function Odb(a){var b,c;for(c=Pvb(a,0);c.c!=c.e.b;){b=az(awb(c),38);qeb(b)}}
function Pdb(a){var b,c;for(c=Pvb(a,0);c.c!=c.e.b;){b=az(awb(c),38);if(!b.g){qeb(b);bwb(c)}}}
function oeb(a){var b;if(a.c){b=a.c.s.Yc()+Vlb(a.c);return b}else{return 0}}
function keb(a,b,c){a.l=c;a.i=b[1][jTb];a.e=b[1][kTb];seb(a,b);return a}
function DV(a,b,c){b-=Dn($doc);c-=En($doc);NO(a,b,c)}
function jqb(a,b){var c,d;for(d=b.sd().rc();d.Vb();){c=az(d.Wb(),52);a.zd(c.Bd(),c.Cd())}}
function Jrb(a,b){var c,d;for(c=0,d=a.c;c<d;++c){if(!b?Psb(a,c)==null:(b==null?null:b)===kz(Psb(a,c))){return c}}return -1}
function leb(a){var b,c;b=a.l.s[a.i];for(c=1;c<a.k;++c){b+=a.l.w+a.l.s[a.i+c]}return b}
function meb(a){var b,c;c=a.l.h[a.e];for(b=1;b<a.f;++b){c+=a.l.v+a.l.h[a.e+b]}return c}
function Xdb(a,b){var c;c=az(this.z.Ad(a),89);if(!c){return}fmb(c,b);this.z.zd(b,c);this.p.zd(az(b,67),az(this.p.td(a),38))}
function Tdb(a){var b;b=az(this.p.td(a),38);return G3(new D3,meb(b)-Vlb(b.c),leb(b)-Slb(b.c))}
function _db(a,b){var c;c=az(this.z.td(a),89);!!c&&imb(c,b,this.e);if(!this.q){teb(az(this.p.td(a),38),b);atb(this.e.d,a)}}
function Sdb(a){var b,c;b=Jy(oG,270,-1,a.length,1);for(c=0;c<b.length;++c){b[c]=a[c]}return b}
function Kdb(a,b){var c,d,e;e=b[1][jTb];d=b[1][kTb];c=a.c[d][e];if(!c){c=keb(new heb,b,a);a.c[d][e]=c}else{seb(c,b)}return c}
function zO(a,b,c,d,e){d=wO(a,b,d);YN(b);tY(a.G,b,d);e?iM(c,b.qb,d):c.appendChild(b.qb);$N(b,a)}
function peb(a,b,c){if(!!a.c&&a.c.mb){MO(a.l.b,a.c,b,c);_lb(a.c,meb(a),leb(a));a.c.b=s9(new p9,a.b);hmb(a.c,meb(a),leb(a))}}
function reb(a){if(!a.d){return false}if(a.h){return false}else{qeb(a);return true}}
function NO(a,b,c){var d;d=a.qb;if(b==-1&&c==-1){OO(d)}else{d.style[gAb]=xBb;d.style[eAb]=b+Szb;d.style[fAb]=c+Szb}}
function GO(a){HO(a,(Jl(),$doc).createElement(GAb));a.qb.style[gAb]=EBb;a.qb.style[yBb]=rBb;return a}
function Ly(a,b,c,d,e,f,g){var h,i,k,l;k=d[e];i=e==f-1;l=Hy(i?g:0,k);Sy();Vy(l,Qy,Ry);l.aC=a[e];l.tI=b[e];l.qI=c[e];if(!i){++e;for(h=0;h<k;++h){l[h]=Ly(a,b,c,d,e,f,g)}}return l}
function Idb(a){var b,c,d,e,f,g,h;if(!Uob(Pxb,a.A)){h=a.m[0];for(g=1;g<a.m.length;++g){h+=a.v+a.m[g]}a.b.qb.style[Rzb]=Pxb;b=parseInt(a.b.qb[Xzb])||0;f=b-h;d=0;if(f>0){for(g=0;g<a.h.length;++g){e=~~(f*a.f[g]/1000);a.h[g]=a.m[g]+e;d+=e}f-=d;c=0;while(f>0){++a.h[c%a.h.length];--f;++c}}}}
function $H(){VH=true;UH=(XH(),new NH);Dj((Aj(),zj),1);!!$stats&&$stats(hk(fTb,_xb,null,null));UH.Tb();!!$stats&&$stats(hk(fTb,gTb,null,null))}
function Ddb(a){a.qb=(Jl(),$doc).createElement(GAb);a.k=$doc.createElement(GAb);a.b=GO(new dN);a.z=lub(new jub);a.p=lub(new jub);a.d=deb(new beb,a,Tyb,a);a.g=Kvb(new Ivb);a.t=Kvb(new Ivb);a.qb.appendChild(a.k);a.qb[Uzb]=iTb;nR(a,a.b);return a}
function teb(a,b){if(!!b&&!Boolean(b[1][KDb])){Tzb in b[1]&&b[1][Tzb].indexOf(SCb)!=-1?(a.g=true):(a.g=false);if(Rzb in b[1]){a.m=a.h=b[1][Rzb].indexOf(SCb)!=-1;Tzb in b[1]&&(a.m=false)}else{a.m=!(Tzb in b[1]);a.h=false}}}
function Edb(a){var b,c,d;for(c=0;c<a.c.length;++c){for(d=0;d<a.c[c].length;++d){b=a.c[c][d];if(b){if(!!b.c&&b.m){b.c.qb.style[Rzb]=meb(b)+Szb;lmb(b.c)}b.k==1?!b.g&&a.s[d]<neb(b)&&(a.s[d]=neb(b)):Rdb(a,b)}}}Hdb(a);a.n=Sdb(a.s)}
function Qdb(a,b){var c,d,e,f;c=null;for(e=Pvb(a.g,0);e.c!=e.e.b;){d=az(awb(e),90);if(d.c<b.f){continue}else{c=d;break}}if(!c){c=yeb(new veb,b.f);Nvb(a.g,c)}else if(c.c!=b.f){f=yeb(new veb,b.f);Osb(a.g,Jrb(a.g,c),f);c=f}Lvb(c.b,b)}
function Rdb(a,b){var c,d,e,f;c=null;for(e=Pvb(a.t,0);e.c!=e.e.b;){d=az(awb(e),90);if(d.c<b.k){continue}else{c=d;break}}if(!c){c=yeb(new veb,b.k);Nvb(a.t,c)}else if(c.c!=b.k){f=yeb(new veb,b.k);Osb(a.t,Jrb(a.t,c),f);c=f}Lvb(c.b,b)}
function Zdb(a){var b,c,d,e;this.qb.style[Tzb]=a;if(!Uob(a,this.i)){this.i=a;if(this.q){this.u=true}else{Jdb(this);Ndb(this);for(c=(d=iqb(this.p).c.rc(),osb(new msb,d));c.b.Vb();){b=az((e=az(c.b.Wb(),52),e.Bd()),67);l_(this.e,az(b,37))}}}}
function Jdb(a){var b,c,d,e,f,g,h;if(!Uob(Pxb,a.i)){h=a.n[0];for(g=1;g<a.n.length;++g){h+=a.w+a.n[g]}b=(parseInt(a.qb[Wzb])||0)-a.l;f=b-h;d=0;if(f>0){for(g=0;g<a.s.length;++g){e=~~(f*a.r[g]/1000);a.s[g]=a.n[g]+e;d+=e}f-=d;c=0;while(f>0){++a.s[c%a.s.length];--f;++c}}}}
function Ndb(a){var b,c,d,e,f,g;f=0;g=0;for(d=0;d<a.c.length;++d){g=0;for(e=0;e<a.c[d].length;++e){c=a.c[d][e];!!c&&peb(c,f,g);g+=a.s[e]+a.w}f+=a.h[d]+a.v}Uob(Pxb,a.A)?(a.b.qb.style[Rzb]=f-a.v+Szb,undefined):(a.b.qb.style[Rzb]=Pxb,undefined);Uob(Pxb,a.i)?(b=g-a.w):(b=(parseInt(a.qb[Wzb])||0)-a.l);a.b.qb.style[Tzb]=b+Szb}
function bI(){var a,c,d;while(SH){d=mi;SH=SH.b;!SH&&(TH=null);if(!d){(L8(),K8).zd(vE,new V8);B$()}else{try{(L8(),K8).zd(vE,new V8);B$()}catch(a){a=OG(a);if(dz(a,5)){c=a;N5.Lc(c)}else throw a}}}}
function Gdb(a){var b,c,d,e,f,g,h,i,k,l;for(h=Pvb(a.g,0);h.c!=h.e.b;){g=az(awb(h),90);for(d=Pvb(g.b,0);d.c!=d.e.b;){c=az(awb(d),38);l=c.h?0:oeb(c);b=a.h[c.e];for(f=1;f<c.f;++f){b+=a.v+a.h[c.e+f]}if(b<l){i=l-b;k=~~(i/c.f);for(f=0;f<c.f;++f){e=c.e+f;a.h[e]+=k;i-=k}if(i>0){for(f=0;f<c.f;++f){e=c.e+f;a.h[e]+=1;i-=1;if(i==0){break}}}}}}}
function Hdb(a){var b,c,d,e,f,g,h,i,k,l;for(h=Pvb(a.t,0);h.c!=h.e.b;){g=az(awb(h),90);for(d=Pvb(g.b,0);d.c!=d.e.b;){c=az(awb(d),38);e=c.g?0:neb(c);b=a.s[c.i];for(f=1;f<c.k;++f){b+=a.w+a.s[c.i+f]}if(b<e){i=e-b;l=~~(i/c.k);for(f=0;f<c.k;++f){k=c.i+f;a.s[k]+=l;i-=l}if(i>0){for(f=0;f<c.k;++f){k=c.i+f;a.s[k]+=1;i-=1;if(i==0){break}}}}}}}
function qeb(a){var b;b=g_(a.l.e,a.d);if(!a.c||a.c.q!=b){if(a.l.z.rd(b)){a.c=az(a.l.z.td(b),89);a.c.qb.style[Rzb]=Pxb;a.c.qb.style[Tzb]=Pxb}else{a.c=Klb(new Hlb,az(b,37),0);a.l.z.zd(az(b,37),a.c);a.c.qb.style[Rzb]=Pxb;JO(a.l.b,a.c,0,0)}a.l.p.zd(b,a)}Ylb(a.c,a.d,a.l.e,-1);a.l.u&&(G4(),Boolean(a.d[1][KDb]))&&l_(a.l.e,a.c.q);lmb(a.c);a.l.o.Ad(b)}
function seb(a,b){var c,d,e;a.f=vTb in b[1]?b[1][vTb]:1;a.k=yIb in b[1]?b[1][yIb]:1;for(c=0;c<a.f;++c){for(d=0;d<a.k;++d){(c>0||d>0)&&Oy(a.l.c[a.e+c],a.i+d,null)}}b=b[2];if(a.d){if(!b){a.c=null}else if(!!a.c&&a.c.q!=g_(a.l.e,b)){a.c=null;e=g_(a.l.e,b);if(a.l.z.rd(e)){a.c=az(a.l.z.td(e),89);a.c.qb.style[Rzb]=Pxb;a.c.qb.style[Tzb]=Pxb;a.l.p.zd(e,a)}}}a.d=b;teb(a,b)}
function $db(a){var b,c,d,e,f,g,h,i,k,l,m,n,o,p,q,r,s,t,u,v;this.qb.style[Rzb]=a;if(!Uob(a,this.A)){this.A=a;if(this.q){this.u=true}else{o=Sdb(this.h);Idb(this);h=false;g=null;for(i=0;i<o.length;++i){if(this.h[i]!=o[i]){f=this.c[i];for(k=0;k<f.length;++k){b=f[k];if(!!b&&!!b.c&&b.m){_lb(b.c,meb(b),leb(b));l_(this.e,b.c.q);lmb(b.c);l=neb(b);if(this.h[i]<o[i]&&l>this.n[k]&&b.k==1){this.n[k]=l;if(l>this.s[k]){this.s[k]=l;h=true}}else if(l<this.n[k]){!g&&(g=tub(new rub));wub(g,lob(k))}}}}}if(g){r=false;for(q=(s=iqb(g.b).c.rc(),osb(new msb,s));q.b.Vb();){p=az((t=az(q.b.Wb(),52),t.Bd()),44);n=this.n[p.b];m=0;for(e=0;e<this.h.length;++e){d=this.c[e][p.b];!!d&&!d.g&&neb(d)>m&&(m=neb(d))}if(m<n){this.n[p.b]=this.s[p.b]=m;r=true}}if(r){Hdb(this);this.n=Sdb(this.s);h=true}}Ndb(this);for(c=(u=iqb(this.p).c.rc(),osb(new msb,u));c.b.Vb();){b=az((v=az(c.b.Wb(),52),v.Bd()),67);l_(this.e,az(b,37))}h&&Uob(Pxb,this.i)&&T4(this,false)}}}
function Ydb(a){var b,c,d,e,f,g,h,i,k,l,m,n,o,p,q,r,s,t,u,v,w,x;n=false;s=false;t=false;o=parseInt(this.b.qb[Wzb])||0;p=parseInt(this.b.qb[Xzb])||0;(Uob(Pxb,this.A)||Uob(Pxb,this.i))&&(n=true);g=Zsb(new Wsb);h=Zsb(new Wsb);for(r=a.rc();r.Vb();){q=az(r.Wb(),67);c=az(this.p.td(q),38);if(!c.g||!c.h){c.c.qb.style[Rzb]=Pxb;c.c.qb.style[Tzb]=Pxb;lmb(c.c);jmb(c.c);x=oeb(c);b=this.h[c.e];for(l=1;l<c.f;++l){b+=this.v+this.h[c.e+l]}if(b<x){n=true;c.f==1?(this.h[c.e]=this.m[c.e]=x):(s=true)}else b!=x&&atb(g,lob(c.e));k=neb(c);b=this.s[c.i];for(l=1;l<c.k;++l){b+=this.w+this.s[c.i+l]}if(b<k){n=true;c.k==1?(this.s[c.i]=this.n[c.i]=k):(t=true)}else b!=k&&atb(h,lob(c.i))}}if(g.c>0){for(e=Xrb(new Urb,g);e.b<e.d.od();){d=az(Zrb(e),44);f=0;for(l=0;l<this.s.length;++l){c=this.c[d.b][l];if(!!c&&!!c.d&&!c.h&&c.f==1){x=oeb(c);x>f&&(f=x)}}this.m[d.b]=f}n=true;this.h=Sdb(this.m);Gdb(this);s=false}s&&Gdb(this);if(h.c>0){n=true;for(w=Xrb(new Urb,h);w.b<w.d.od();){v=az(Zrb(w),44);u=this.n[v.b]=0;for(l=0;l<this.h.length;++l){c=this.c[l][v.b];if(!!c&&!!c.d&&!c.g&&c.k==1){i=neb(c);i>u&&(u=i)}}this.n[v.b]=u}this.s=Sdb(this.n);Hdb(this);t=false}t&&Hdb(this);if(n){Idb(this);Jdb(this);Ndb(this);for(l=0;l<this.c.length;++l){for(m=0;m<this.c[l].length;++m){c=this.c[l][m];!!c&&!!c.c&&(c.g||c.h)&&l_(this.e,c.c.q)}}}if((parseInt(this.b.qb[Wzb])||0)!=o||(parseInt(this.b.qb[Xzb])||0)!=p){return false}else{return true}}
function aeb(a,b){var c,d,e,f,g,h,i,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;this.q=true;this.e=b;if(J_(b,this,a,true)){this.q=false;return}y9(this.d,b);this.b.qb.style[Rzb]=lBb;v=Neb(new Leb,a[1][lTb]);w=mTb;(v.b&1)==1&&(w+=nTb);(v.b&2)==2&&(w+=oTb);(v.b&4)==4&&(w+=pTb);(v.b&8)==8&&(w+=qTb);this.k.className=w;this.l=(this.k.offsetHeight||0)-(parseInt(this.b.qb[Wzb])||0);x=(Jl(),$doc).createElement(GAb);x.className=rTb+(Boolean(a[1][sTb])?tTb:uTb);x.style[Rzb]=zzb;x.style[Tzb]=zzb;this.b.qb.appendChild(x);this.v=x.offsetWidth||0;this.w=x.offsetHeight||0;this.b.qb.removeChild(x);i=a[1][vTb];r=a[1][yIb];this.h=Jy(oG,270,-1,i,1);this.s=Jy(oG,270,-1,r,1);if(this.c==null){this.c=Ly([HG,yG],[282,268],[47,38],[i,r],0,2,0)}else if(this.c.length!=i||this.c[0].length!=r){m=Ly([HG,yG],[282,268],[47,38],[i,r],0,2,0);for(k=0;k<this.c.length;++k){for(l=0;l<this.c[k].length;++l){k<i&&l<r&&(m[k][l]=this.c[k][l])}}this.c=m}this.o=nub(new jub,this.z);d=z8(a[1],wTb);c=0;n=Kvb(new Ivb);p=Kvb(new Ivb);for(k=r4(new o4,a);y=k.c.length-2,y>k.b+1;){o=bz(t4(k));if(Uob(xTb,o[0])){for(l=r4(new o4,o);z=l.c.length-2,z>l.b+1;){e=bz(t4(l));if(Uob(yTb,e[0])){f=Kdb(this,e);if(f.d){q=reb(f);f.b=d[c++];if(!q){kwb(new hwb,f,n.b);++n.c}f.f>1?Qdb(this,f):q&&this.h[f.e]<oeb(f)&&(this.h[f.e]=oeb(f));if(f.g){kwb(new hwb,f,p.b);++p.c}}}}}}Gdb(this);this.f=z8(a[1],zTb);this.r=z8(a[1],ATb);this.m=Sdb(this.h);Idb(this);Pdb(n);Edb(this);Jdb(this);Odb(n);for(g=Pvb(p,0);g.c!=g.e.b;){f=az(awb(g),38);u=f.c.q;k_(b,b.h[u.qb.tkPid]);lmb(f.c)}Ndb(this);for(t=(A=iqb(this.o).c.rc(),osb(new msb,A));t.b.Vb();){s=az((B=az(t.b.Wb(),52),B.Bd()),37);h=az(this.z.td(s),89);this.p.Ad(s);this.z.Ad(s);YN(h);I_(b,az(s,67))}this.o=null;this.q=false;this.u=false}
var pTb=' v-gridlayout-margin-bottom',qTb=' v-gridlayout-margin-left',oTb=' v-gridlayout-margin-right',nTb=' v-gridlayout-margin-top',BTb='AsyncLoader1',HTb='VGridLayout$1',CTb='VGridLayout$Cell',ETb='VGridLayout$Cell;',GTb='VGridLayout$SpanList',hTb='Widget must be a child of this panel.',ITb='WidgetMapImpl$2$1',DTb='[Lcom.vaadin.terminal.gwt.client.ui.',FTb='[[Lcom.vaadin.terminal.gwt.client.ui.',zTb='colExpand',yTb='gc',xTb='gr',uTb='off',tTb='on',ATb='rowExpand',fTb='runCallbacks1',iTb='v-gridlayout',mTb='v-gridlayout-margin',rTb='v-gridlayout-spacing-',vTb='w',kTb='x',jTb='y';_=NH.prototype=new OH;_.gC=ZH;_.Tb=bI;_.tI=0;_=dN.prototype;_.sc=RO;_=zV.prototype;_.sc=DV;_=V8.prototype=new wh;_.bd=X8;_.gC=Y8;_.tI=148;_=Adb.prototype=new iR;_.Pc=Tdb;_.gC=Udb;_.xc=Vdb;_.Qc=Wdb;_.Rc=Xdb;_.Sc=Ydb;_.ec=Zdb;_.hc=$db;_.Tc=_db;_.Wc=aeb;_.tI=174;_.c=null;_.e=null;_.f=null;_.h=null;_.i=null;_.l=0;_.m=null;_.n=null;_.o=null;_.q=false;_.r=null;_.s=null;_.u=false;_.v=0;_.w=0;_.A=null;_=beb.prototype=new R9;_.fd=eeb;_.gC=feb;_.ed=geb;_.tI=175;_.b=null;_=heb.prototype=new wh;_.gC=ueb;_.tI=176;_.b=0;_.c=null;_.d=null;_.e=0;_.f=1;_.g=false;_.h=false;_.i=0;_.k=1;_.l=null;_.m=false;_=veb.prototype=new wh;_.gC=zeb;_.tI=177;_.c=0;var aB=knb(cOb,BTb),tE=knb(dQb,CTb),yG=jnb(DTb,ETb),HG=jnb(FTb,ETb),uE=knb(dQb,GTb),sE=knb(dQb,HTb),LD=knb(gRb,ITb);$H();