function oH(){}
function r8(){}
function Ycb(){}
function zdb(){}
function Fdb(){}
function Tdb(){}
function u8(){return nD}
function AH(){return EA}
function qdb(){return ZD}
function Ddb(){return WD}
function Sdb(){return XD}
function Xdb(){return YD}
function rdb(){return this.k}
function t8(){return _cb(new Ycb)}
function oO(a,b,c){kO(a,b,c)}
function jO(a,b,c,d){hO(a,b);a.uc(b,c,d)}
function hdb(a,b){return j4(a.e,a,b)}
function sdb(a){return this.p.vd(a)}
function Cdb(a){return hdb(this.b,a)}
function Edb(a,b){return mN(this.b,a,b)}
function Wdb(a,b){a.b=gvb(new evb);a.c=b;return a}
function Ltb(a,b){Upb(a);Hpb(a,b);return a}
function Bdb(a,b,c,d){a.b=d;a.h=b;a.c=c;return a}
function eO(a,b){a.E=OX(new MX,a);a.ob=b;return a}
function Ldb(a){if(a.c){return a.c.s._c()+olb(a.c)}else{return 0}}
function WN(a,b){if(b<0||b>a.E.d){throw vnb(new tnb)}}
function hO(a,b){if(b.nb!=a){throw mnb(new jnb,wSb)}}
function gO(a,b,c,d){var e;vN(b);e=a.E.d;a.uc(b,c,d);YN(a,b,a.ob,e,true)}
function VN(a,b,c){var d;WN(a,c);if(b.nb==a){d=RX(a.E,b);d<c&&--c}return c}
function kdb(a){var b,c;for(c=lvb(a,0);c.c!=c.e.b;){b=Hy(yvb(c),37);Odb(b)}}
function ldb(a){var b,c;for(c=lvb(a,0);c.c!=c.e.b;){b=Hy(yvb(c),37);if(!b.g){Odb(b);zvb(c)}}}
function Mdb(a){var b;if(a.c){b=a.c.s.ad()+rlb(a.c);return b}else{return 0}}
function Pdb(a){if(!a.d){return false}if(a.h){return false}else{Odb(a);return true}}
function Idb(a,b,c){a.l=c;a.i=b[1][ySb];a.e=b[1][zSb];Qdb(a,b);return a}
function aV(a,b,c){b-=Hn($doc);c-=In($doc);kO(a,b,c)}
function Hpb(a,b){var c,d;for(d=b.wd().tc();d.Xb();){c=Hy(d.Yb(),51);a.Dd(c.Fd(),c.Gd())}}
function frb(a,b){var c,d;for(c=0,d=a.c;c<d;++c){if(!b?lsb(a,c)==null:(b==null?null:b)===Ry(lsb(a,c))){return c}}return -1}
function Kdb(a){var b,c;c=a.l.h[a.e];for(b=1;b<a.f;++b){c+=a.l.v+a.l.h[a.e+b]}return c}
function Jdb(a){var b,c;b=a.l.s[a.i];for(c=1;c<a.k;++c){b+=a.l.w+a.l.s[a.i+c]}return b}
function odb(a){var b,c;b=oy(SF,263,-1,a.length,1);for(c=0;c<b.length;++c){b[c]=a[c]}return b}
function tdb(a,b){var c;c=Hy(this.x.Ed(a),88);if(!c){return}Dlb(c,b);this.x.Dd(b,c);this.p.Dd(Hy(b,66),Hy(this.p.xd(a),37))}
function pdb(a){var b;b=Hy(this.p.xd(a),37);return d3(new a3,Kdb(b)-rlb(b.c),Jdb(b)-olb(b.c))}
function xdb(a,b){var c;c=Hy(this.x.xd(a),88);!!c&&Glb(c,b,this.e);if(!this.q){Rdb(Hy(this.p.xd(a),37),b);ysb(this.e.d,a)}}
function YN(a,b,c,d,e){d=VN(a,b,d);vN(b);SX(a.E,b,d);e?ML(c,b.ob,d):c.appendChild(b.ob);xN(b,a)}
function Ndb(a,b,c){if(!!a.c&&a.c.kb){jO(a.l.b,a.c,b,c);xlb(a.c,Kdb(a),Jdb(a));a.c.b=Q8(new N8,a.b);Flb(a.c,Kdb(a),Jdb(a))}}
function dO(a){eO(a,(Yl(),$doc).createElement(dAb));a.ob.style[Lxb]=bBb;a.ob.style[XAb]=RAb;return a}
function kO(a,b,c){var d;d=a.ob;if(b==-1&&c==-1){lO(d)}else{d.style[Lxb]=Pxb;d.style[Dzb]=b+pzb;d.style[Ezb]=c+pzb}}
function gdb(a,b){var c,d,e;e=b[1][ySb];d=b[1][zSb];c=a.c[d][e];if(!c){c=Idb(new Fdb,b,a);a.c[d][e]=c}else{Qdb(c,b)}return c}
function EH(){var a,c,d;while(tH){d=ii;tH=tH.b;!tH&&(uH=null);if(!d){(h8(),g8).Dd(ZD,new r8);$Z()}else{try{(h8(),g8).Dd(ZD,new r8);$Z()}catch(a){a=pG(a);if(Ky(a,5)){c=a;k5.Pc(c)}else throw a}}}}
function Rdb(a,b){if(!!b&&!Boolean(b[1][eDb])){qzb in b[1]&&b[1][qzb].indexOf(mCb)!=-1?(a.g=true):(a.g=false);if(ozb in b[1]){a.m=a.h=b[1][ozb].indexOf(mCb)!=-1;qzb in b[1]&&(a.m=false)}else{a.m=!(qzb in b[1]);a.h=false}}}
function adb(a){var b,c,d;for(c=0;c<a.c.length;++c){for(d=0;d<a.c[c].length;++d){b=a.c[c][d];if(b){if(!!b.c&&b.m){b.c.ob.style[ozb]=Kdb(b)+pzb;Jlb(b.c)}b.k==1?!b.g&&a.s[d]<Ldb(b)&&(a.s[d]=Ldb(b)):ndb(a,b)}}}ddb(a);a.n=odb(a.s)}
function mdb(a,b){var c,d,e,f;c=null;for(e=lvb(a.g,0);e.c!=e.e.b;){d=Hy(yvb(e),89);if(d.c<b.f){continue}else{c=d;break}}if(!c){c=Wdb(new Tdb,b.f);jvb(a.g,c)}else if(c.c!=b.f){f=Wdb(new Tdb,b.f);ksb(a.g,frb(a.g,c),f);c=f}hvb(c.b,b)}
function ndb(a,b){var c,d,e,f;c=null;for(e=lvb(a.t,0);e.c!=e.e.b;){d=Hy(yvb(e),89);if(d.c<b.k){continue}else{c=d;break}}if(!c){c=Wdb(new Tdb,b.k);jvb(a.t,c)}else if(c.c!=b.k){f=Wdb(new Tdb,b.k);ksb(a.t,frb(a.t,c),f);c=f}hvb(c.b,b)}
function vdb(a){var b,c,d,e;this.ob.style[qzb]=a;if(!qob(a,this.i)){this.i=a;if(this.q){this.u=true}else{fdb(this);jdb(this);for(c=(d=Gpb(this.p).c.tc(),Mrb(new Krb,d));c.b.Xb();){b=Hy((e=Hy(c.b.Yb(),51),e.Fd()),66);K$(this.e,Hy(b,36))}}}}
function _cb(a){a.ob=(Yl(),$doc).createElement(dAb);a.k=$doc.createElement(dAb);a.b=dO(new CM);a.x=Jtb(new Htb);a.p=Jtb(new Htb);a.d=Bdb(new zdb,a,syb,a);a.g=gvb(new evb);a.t=gvb(new evb);a.ob.appendChild(a.k);a.ob[rzb]=xSb;NQ(a,a.b);return a}
function BH(){wH=true;vH=(yH(),new oH);zj((wj(),vj),1);!!$stats&&$stats(dk(uSb,xxb,null,null));vH.Vb();!!$stats&&$stats(dk(uSb,vSb,null,null))}
function fdb(a){var b,c,d,e,f,g,h;if(!qob(lxb,a.i)){h=a.n[0];for(g=1;g<a.n.length;++g){h+=a.w+a.n[g]}b=(parseInt(a.ob[tzb])||0)-a.l;f=b-h;d=0;if(f>0){for(g=0;g<a.s.length;++g){e=~~(f*a.r[g]/1000);a.s[g]=a.n[g]+e;d+=e}f-=d;c=0;while(f>0){++a.s[c%a.s.length];--f;++c}}}}
function edb(a){var b,c,d,e,f,g,h;if(!qob(lxb,a.y)){h=a.m[0];for(g=1;g<a.m.length;++g){h+=a.v+a.m[g]}a.b.ob.style[ozb]=lxb;b=parseInt(a.b.ob[uzb])||0;f=b-h;d=0;if(f>0){for(g=0;g<a.h.length;++g){e=~~(f*a.f[g]/1000);a.h[g]=a.m[g]+e;d+=e}f-=d;c=0;while(f>0){++a.h[c%a.h.length];--f;++c}}}}
function qy(a,b,c,d,e,f,g){var h,i,k,l;k=d[e];i=e==f-1;l=my(i?g:0,k);xy();Ay(l,vy,wy);l.aC=a[e];l.tI=b[e];l.qI=c[e];if(!i){++e;for(h=0;h<k;++h){l[h]=qy(a,b,c,d,e,f,g)}}return l}
function jdb(a){var b,c,d,e,f,g;f=0;g=0;for(d=0;d<a.c.length;++d){g=0;for(e=0;e<a.c[d].length;++e){c=a.c[d][e];!!c&&Ndb(c,f,g);g+=a.s[e]+a.w}f+=a.h[d]+a.v}qob(lxb,a.y)?(a.b.ob.style[ozb]=f-a.v+pzb,undefined):(a.b.ob.style[ozb]=lxb,undefined);qob(lxb,a.i)?(b=g-a.w):(b=(parseInt(a.ob[tzb])||0)-a.l);a.b.ob.style[qzb]=b+pzb}
function cdb(a){var b,c,d,e,f,g,h,i,k,l;for(h=lvb(a.g,0);h.c!=h.e.b;){g=Hy(yvb(h),89);for(d=lvb(g.b,0);d.c!=d.e.b;){c=Hy(yvb(d),37);l=c.h?0:Mdb(c);b=a.h[c.e];for(f=1;f<c.f;++f){b+=a.v+a.h[c.e+f]}if(b<l){i=l-b;k=~~(i/c.f);for(f=0;f<c.f;++f){e=c.e+f;a.h[e]+=k;i-=k}if(i>0){for(f=0;f<c.f;++f){e=c.e+f;a.h[e]+=1;i-=1;if(i==0){break}}}}}}}
function ddb(a){var b,c,d,e,f,g,h,i,k,l;for(h=lvb(a.t,0);h.c!=h.e.b;){g=Hy(yvb(h),89);for(d=lvb(g.b,0);d.c!=d.e.b;){c=Hy(yvb(d),37);e=c.g?0:Ldb(c);b=a.s[c.i];for(f=1;f<c.k;++f){b+=a.w+a.s[c.i+f]}if(b<e){i=e-b;l=~~(i/c.k);for(f=0;f<c.k;++f){k=c.i+f;a.s[k]+=l;i-=l}if(i>0){for(f=0;f<c.k;++f){k=c.i+f;a.s[k]+=1;i-=1;if(i==0){break}}}}}}}
function Odb(a){var b;b=F$(a.l.e,a.d);if(!a.c||a.c.q!=b){if(a.l.x.vd(b)){a.c=Hy(a.l.x.xd(b),88);a.c.ob.style[ozb]=lxb;a.c.ob.style[qzb]=lxb}else{a.c=glb(new dlb,Hy(b,36),0);a.l.x.Dd(Hy(b,36),a.c);a.c.ob.style[ozb]=lxb;gO(a.l.b,a.c,0,0)}a.l.p.Dd(b,a)}ulb(a.c,a.d,a.l.e,-1);a.l.u&&(d4(),Boolean(a.d[1][eDb]))&&K$(a.l.e,a.c.q);Jlb(a.c);a.l.o.Ed(b)}
function Qdb(a,b){var c,d,e;a.f=KSb in b[1]?b[1][KSb]:1;a.k=RHb in b[1]?b[1][RHb]:1;for(c=0;c<a.f;++c){for(d=0;d<a.k;++d){(c>0||d>0)&&ty(a.l.c[a.e+c],a.i+d,null)}}b=b[2];if(a.d){if(!b){a.c=null}else if(!!a.c&&a.c.q!=F$(a.l.e,b)){a.c=null;e=F$(a.l.e,b);if(a.l.x.vd(e)){a.c=Hy(a.l.x.xd(e),88);a.c.ob.style[ozb]=lxb;a.c.ob.style[qzb]=lxb;a.l.p.Dd(e,a)}}}a.d=b;Rdb(a,b)}
function wdb(a){var b,c,d,e,f,g,h,i,k,l,m,n,o,p,q,r,s,t,u,v;this.ob.style[ozb]=a;if(!qob(a,this.y)){this.y=a;if(this.q){this.u=true}else{o=odb(this.h);edb(this);h=false;g=null;for(i=0;i<o.length;++i){if(this.h[i]!=o[i]){f=this.c[i];for(k=0;k<f.length;++k){b=f[k];if(!!b&&!!b.c&&b.m){xlb(b.c,Kdb(b),Jdb(b));K$(this.e,b.c.q);Jlb(b.c);l=Ldb(b);if(this.h[i]<o[i]&&l>this.n[k]&&b.k==1){this.n[k]=l;if(l>this.s[k]){this.s[k]=l;h=true}}else if(l<this.n[k]){!g&&(g=Rtb(new Ptb));Utb(g,Jnb(k))}}}}}if(g){r=false;for(q=(s=Gpb(g.b).c.tc(),Mrb(new Krb,s));q.b.Xb();){p=Hy((t=Hy(q.b.Yb(),51),t.Fd()),43);n=this.n[p.b];m=0;for(e=0;e<this.h.length;++e){d=this.c[e][p.b];!!d&&!d.g&&Ldb(d)>m&&(m=Ldb(d))}if(m<n){this.n[p.b]=this.s[p.b]=m;r=true}}if(r){ddb(this);this.n=odb(this.s);h=true}}jdb(this);for(c=(u=Gpb(this.p).c.tc(),Mrb(new Krb,u));c.b.Xb();){b=Hy((v=Hy(c.b.Yb(),51),v.Fd()),66);K$(this.e,Hy(b,36))}h&&qob(lxb,this.i)&&q4(this,false)}}}
function udb(a){var b,c,d,e,f,g,h,i,k,l,m,n,o,p,q,r,s,t,u,v,w,x;n=false;s=false;t=false;o=parseInt(this.b.ob[tzb])||0;p=parseInt(this.b.ob[uzb])||0;(qob(lxb,this.y)||qob(lxb,this.i))&&(n=true);g=vsb(new ssb);h=vsb(new ssb);for(r=a.tc();r.Xb();){q=Hy(r.Yb(),66);c=Hy(this.p.xd(q),37);if(!c.g||!c.h){c.c.ob.style[ozb]=lxb;c.c.ob.style[qzb]=lxb;Jlb(c.c);Hlb(c.c);x=Mdb(c);b=this.h[c.e];for(l=1;l<c.f;++l){b+=this.v+this.h[c.e+l]}if(b<x){n=true;c.f==1?(this.h[c.e]=this.m[c.e]=x):(s=true)}else b!=x&&ysb(g,Jnb(c.e));k=Ldb(c);b=this.s[c.i];for(l=1;l<c.k;++l){b+=this.w+this.s[c.i+l]}if(b<k){n=true;c.k==1?(this.s[c.i]=this.n[c.i]=k):(t=true)}else b!=k&&ysb(h,Jnb(c.i))}}if(g.c>0){for(e=trb(new qrb,g);e.b<e.d.sd();){d=Hy(vrb(e),43);f=0;for(l=0;l<this.s.length;++l){c=this.c[d.b][l];if(!!c&&!!c.d&&!c.h&&c.f==1){x=Mdb(c);x>f&&(f=x)}}this.m[d.b]=f}n=true;this.h=odb(this.m);cdb(this);s=false}s&&cdb(this);if(h.c>0){n=true;for(w=trb(new qrb,h);w.b<w.d.sd();){v=Hy(vrb(w),43);u=this.n[v.b]=0;for(l=0;l<this.h.length;++l){c=this.c[l][v.b];if(!!c&&!!c.d&&!c.g&&c.k==1){i=Ldb(c);i>u&&(u=i)}}this.n[v.b]=u}this.s=odb(this.n);ddb(this);t=false}t&&ddb(this);if(n){edb(this);fdb(this);jdb(this);for(l=0;l<this.c.length;++l){for(m=0;m<this.c[l].length;++m){c=this.c[l][m];!!c&&!!c.c&&(c.g||c.h)&&K$(this.e,c.c.q)}}}if((parseInt(this.b.ob[tzb])||0)!=o||(parseInt(this.b.ob[uzb])||0)!=p){return false}else{return true}}
function ydb(a,b){var c,d,e,f,g,h,i,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;this.q=true;this.e=b;if(g_(b,this,a,true)){this.q=false;return}W8(this.d,b);this.b.ob.style[ozb]=KAb;v=jeb(new heb,a[1][ASb]);w=BSb;(v.b&1)==1&&(w+=CSb);(v.b&2)==2&&(w+=DSb);(v.b&4)==4&&(w+=ESb);(v.b&8)==8&&(w+=FSb);this.k.className=w;this.l=(this.k.offsetHeight||0)-(parseInt(this.b.ob[tzb])||0);x=(Yl(),$doc).createElement(dAb);x.className=GSb+(Boolean(a[1][HSb])?ISb:JSb);x.style[ozb]=$yb;x.style[qzb]=$yb;this.b.ob.appendChild(x);this.v=x.offsetWidth||0;this.w=x.offsetHeight||0;this.b.ob.removeChild(x);i=a[1][KSb];r=a[1][RHb];this.h=oy(SF,263,-1,i,1);this.s=oy(SF,263,-1,r,1);if(this.c==null){this.c=qy([iG,_F],[275,261],[46,37],[i,r],0,2,0)}else if(this.c.length!=i||this.c[0].length!=r){m=qy([iG,_F],[275,261],[46,37],[i,r],0,2,0);for(k=0;k<this.c.length;++k){for(l=0;l<this.c[k].length;++l){k<i&&l<r&&(m[k][l]=this.c[k][l])}}this.c=m}this.o=Ltb(new Htb,this.x);d=X7(a[1],LSb);c=0;n=gvb(new evb);p=gvb(new evb);for(k=Q3(new N3,a);y=k.c.length-2,y>k.b+1;){o=Iy(S3(k));if(qob(MSb,o[0])){for(l=Q3(new N3,o);z=l.c.length-2,z>l.b+1;){e=Iy(S3(l));if(qob(NSb,e[0])){f=gdb(this,e);if(f.d){q=Pdb(f);f.b=d[c++];if(!q){Ivb(new Fvb,f,n.b);++n.c}f.f>1?mdb(this,f):q&&this.h[f.e]<Mdb(f)&&(this.h[f.e]=Mdb(f));if(f.g){Ivb(new Fvb,f,p.b);++p.c}}}}}}cdb(this);this.f=X7(a[1],OSb);this.r=X7(a[1],PSb);this.m=odb(this.h);edb(this);ldb(n);adb(this);fdb(this);kdb(n);for(g=lvb(p,0);g.c!=g.e.b;){f=Hy(yvb(g),37);u=f.c.q;J$(b,b.h[u.ob.tkPid]);Jlb(f.c)}jdb(this);for(t=(A=Gpb(this.o).c.tc(),Mrb(new Krb,A));t.b.Xb();){s=Hy((B=Hy(t.b.Yb(),51),B.Fd()),36);h=Hy(this.x.xd(s),88);this.p.Ed(s);this.x.Ed(s);vN(h);f_(b,Hy(s,66))}this.o=null;this.q=false;this.u=false}
var ESb=' v-gridlayout-margin-bottom',FSb=' v-gridlayout-margin-left',DSb=' v-gridlayout-margin-right',CSb=' v-gridlayout-margin-top',QSb='AsyncLoader1',WSb='VGridLayout$1',RSb='VGridLayout$Cell',TSb='VGridLayout$Cell;',VSb='VGridLayout$SpanList',wSb='Widget must be a child of this panel.',XSb='WidgetMapImpl$2$1',SSb='[Lcom.vaadin.terminal.gwt.client.ui.',USb='[[Lcom.vaadin.terminal.gwt.client.ui.',OSb='colExpand',NSb='gc',MSb='gr',JSb='off',ISb='on',PSb='rowExpand',uSb='runCallbacks1',xSb='v-gridlayout',BSb='v-gridlayout-margin',GSb='v-gridlayout-spacing-',KSb='w',zSb='x',ySb='y';_=oH.prototype=new pH;_.gC=AH;_.Vb=EH;_.tI=0;_=CM.prototype;_.uc=oO;_=YU.prototype;_.uc=aV;_=r8.prototype=new sh;_.fd=t8;_.gC=u8;_.tI=142;_=Ycb.prototype=new IQ;_.Tc=pdb;_.gC=qdb;_.zc=rdb;_.Uc=sdb;_.Vc=tdb;_.Wc=udb;_.gc=vdb;_.jc=wdb;_.Xc=xdb;_.$c=ydb;_.tI=168;_.c=null;_.e=null;_.f=null;_.h=null;_.i=null;_.l=0;_.m=null;_.n=null;_.o=null;_.q=false;_.r=null;_.s=null;_.u=false;_.v=0;_.w=0;_.y=null;_=zdb.prototype=new n9;_.kd=Cdb;_.gC=Ddb;_.jd=Edb;_.tI=169;_.b=null;_=Fdb.prototype=new sh;_.gC=Sdb;_.tI=170;_.b=0;_.c=null;_.d=null;_.e=0;_.f=1;_.g=false;_.h=false;_.i=0;_.k=1;_.l=null;_.m=false;_=Tdb.prototype=new sh;_.gC=Xdb;_.tI=171;_.c=0;var EA=Imb(rNb,QSb),XD=Imb(sPb,RSb),_F=Hmb(SSb,TSb),iG=Hmb(USb,TSb),YD=Imb(sPb,VSb),WD=Imb(sPb,WSb),nD=Imb(vQb,XSb);BH();