function eI(){}
function e9(){}
function wfb(){}
function vfb(){}
function wgb(){}
function Rib(){}
function Alb(){}
function Amb(){}
function h9(){return mD}
function qI(){return HA}
function Nfb(){return KE}
function qgb(){return dE}
function Agb(){return cE}
function Uib(){return vE}
function Elb(){return JE}
function Imb(){return NE}
function Qfb(a){Kfb(this,a)}
function Sfb(){Sfb=Bwb;Bfb()}
function Sib(){Sib=Bwb;Sfb()}
function Rfb(a,b){Lfb(this,a,b)}
function Ofb(a){return this.B.qd(a)}
function g9(){return Tib(new Rib)}
function zgb(a){return _fb(this.a,a)}
function Bgb(a,b){return BN(this.a,a,b)}
function Emb(a,b){a.b=b;a.f=a.e+a.b}
function Fmb(a,b){a.c=b;a.a=a.c+a.d}
function Gmb(a,b){a.d=b;a.a=a.c+a.d}
function Hmb(a,b){a.e=b;a.f=a.e+a.b}
function _fb(a,b){return M4(a.u,a,b)}
function ggb(a,b){b<0&&(b=0);a.a.e=b}
function hgb(a,b){b<0&&(b=0);a.a.f=b}
function igb(a,b){a.nb.style[cAb]=b+a.q.f+bAb}
function Ffb(a,b){return Gy(a.B.sd(b),88)}
function Flb(){return MUb+this.a+NUb+this.b+tFb}
function Slb(a){if(!a.e){return 0}return a.g}
function Dlb(a,b,c){a.a=b;a.b=c;return a}
function ygb(a,b,c,d){a.a=d;a.g=b;a.b=c;return a}
function jgb(a,b){a.nb.style[aAb]=b+a.q.a+bAb}
function Gfb(a){var b;b=a.D.c;if(b<1){return null}return Gy($X(a.D,0),88)}
function egb(a){var b;b=Xfb(a);if(a.B.nd()!=0){Zfb(a,b);Wfb(a)}}
function dgb(a){var b;b=r3(new p3,a.a.Xc(),a.a.Wc());Xfb(a);!s3(b,a.a)&&Wfb(a)}
function cgb(a,b){var c,d,e;d=b.r;e=d.Xc()+Ulb(b);if(!lmb(b,a.h)){c=Slb(b);c>e&&(e=c)}return e}
function Plb(a,b,c){b==1?(a.l.f=a.l.Xc()+c,undefined):(a.l.e=a.l.Wc()+c,undefined)}
function Dmb(a,b,c,d,e){a.e=b;a.b=c;a.c=d;a.d=e;a.a=a.c+a.d;a.f=a.e+a.b;return a}
function lmb(a,b){var c;b==1?(c=a.p.nb.style[aAb]):(c=a.p.nb.style[cAb]);return c!=null&&!Tob(c,Pxb)}
function Kfb(a,b){a.nb[dAb]=b;if(a.jb&&a.y||!Tob(a.x,b)){Ifb(a);a.x=b;a.y=false}}
function $fb(a,b){if(u8(a.b,b)){return r9(new o9,a.b[b])}else{return q9(),p9}}
function Vlb(a,b){if(!a.o){return false}if(b==1){return a.o.b>=0}else{return a.o.a>=0}}
function Pfb(a,b){var c;c=Gy(this.B.zd(a),88);if(!c){return}emb(c,b);s_(this.u,Gy(a,66));this.B.yd(b,c)}
function ugb(a,b){var c;c=Ffb(this,Gy(a,36));hmb(c,b,this.u);!this.g&&(atb(this.u.c,a),undefined)}
function Jmb(){return OUb+this.c+PUb+this.e+QUb+this.d+RUb+this.b+tFb}
function Bfb(){Bfb=Bwb;var a;xfb=_l((xl(),$doc),kyb);xfb.innerHTML=xUb;a=xfb.childNodes;yfb=a[0];zfb=Ll(yfb);Afb=a[1]}
function Tib(a){Sib();Dfb(a);a.a=r3(new p3,0,0);a.c=ygb(new wgb,a,Syb,a);Kfb(a,GUb);a.h=0;a.p=HUb;a.o=IUb;a.n=JUb;a.l=KUb;a.m=LUb;return a}
function ogb(a){var b,c,d;for(c=(d=kqb(a.B).b.qc(),Fsb(new Dsb,d));c.a.Sb();){b=Gy(Gy(c.a.Tb(),51).Bd(),88);kmb(b)}}
function rgb(a){var b,c,d,e,f;for(d=a.qc();d.Sb();){c=Gy(d.Tb(),66);b=Ffb(this,Gy(c,36));kmb(b);imb(b)}f=r3(new p3,this.a.Xc(),this.a.Wc());fgb(this);e=s3(f,this.a);!e&&g_(this.u,this);return e}
function Olb(a,b,c){var d;d=~~Math.max(Math.min(c*a.n,2147483647),-2147483648);b==1?(a.l.f=d,undefined):(a.l.e=d,undefined);return d}
function Lfb(a,b,c){var d,e;a.u=c;if(Boolean(b[1][oEb])){return}Mfb(a,b);if(t_(c,a,b,true)){return}e=aAb in b[1]?b[1][aAb]:Pxb;d=cAb in b[1]?b[1][cAb]:Pxb;Tob(e,Pxb)?(a.w=true):(a.w=false);Tob(d,Pxb)?(a.v=true):(a.v=false)}
function mgb(a,b,c,d,e){var f,g;if(!a.v&&!a.w){return a.a}g=0;f=0;if(a.h==1){a.w&&(g=b);a.v&&(f=e)}else{a.w&&(g=d);a.v&&(f=c)}if(a.w){hgb(a,g);jgb(a,a.a.Xc())}if(a.v){ggb(a,f);igb(a,a.a.Wc())}return a.a}
function ngb(a){var b,c,d,e,f;d=1-a.h;if(d==1&&!a.w||d==0&&!a.v){return false}e=false;for(c=(f=kqb(a.B).b.qc(),Fsb(new Dsb,f));c.a.Sb();){b=Gy(Gy(c.a.Tb(),51).Bd(),88);Vlb(b,d)&&X$(a.u,b.p);e=true}return e}
function Zfb(a,b){var c,d,e,f,g;e=b;for(d=(g=kqb(a.B).b.qc(),Fsb(new Dsb,g));d.a.Sb();){c=Gy(Gy(d.a.Tb(),51).Bd(),88);e-=Olb(c,a.h,b)}if(e>0){f=jY(new gY,a.D);while(f.a<f.b.c-1&&e-->0){c=Gy(lY(f),88);Plb(c,a.h,1)}}}
function Mfb(a,b){var c,d;if(!(pEb in b[1])){c=b[1][KTb];if(a.r.a!=c){a.r=Meb(new Keb,c);a.y=true}d=Boolean(b[1][RTb]);if(d!=a.A){a.y=true;a.A=d}}}
function fgb(a){var b,c,d;egb(a);if(!(a.v&&a.w)){for(c=(d=kqb(a.B).b.qc(),Fsb(new Dsb,d));c.a.Sb();){b=Gy(Gy(c.a.Tb(),51).Bd(),88);X$(a.u,b.p);kmb(b)}}if(a.v){ogb(a);egb(a)}ngb(a);Vfb(a);a.z.style[aAb]=a.a.Xc()+(Yq(),bAb);a.z.style[cAb]=a.a.Wc()+bAb}
function rI(){mI=true;lI=(oI(),new eI);wj((tj(),sj),3);!!$stats&&$stats(ak(wUb,_xb,null,null));lI.Qb();!!$stats&&$stats(ak(wUb,FTb,null,null))}
function Efb(a,b,c){var d;if(b.mb==a){if(_X(a.D,b)!=c){KN(b);aY(a.D,b,c);a.z.insertBefore(b.nb,a.z.childNodes[c]);MN(b,a)}}else{a.B.yd(b.p,b);aY(a.D,b,c);d=true;a.B.nd()==c&&(d=false);d?a.z.insertBefore(b.nb,a.z.childNodes[c]):a.z.insertBefore(b.nb,a.t);MN(b,a)}}
function sgb(a){var b,c;c=r3(new p3,this.a.Xc(),this.a.Wc());this.nb.style[cAb]=a;a!=null&&!Tob(a,Pxb)&&ggb(this,(parseInt(this.nb[fAb])||0)-this.q.f);if(this.g){this.i=true}else{fgb(this);b=s3(c,this.a);!b&&g_(this.u,this)}}
function pgb(a){var b,c,d,e;e=0;c=0;b=Gy(this.B.sd(a),88);if(this.h==0){e=this.a.Xc();e-=Ulb(b)}else if(!this.w){e=b.i.Xc();e-=Ulb(b)}if(this.h==1){c=this.a.Wc();c-=Rlb(b)}else if(!this.v){c=b.i.Wc();c-=Rlb(b)}d=G3(new D3,e,c);return d}
function lgb(a){var b,c,d,e;d=Gfb(a);if(d){d.k.style[UBb]=0+(Yq(),bAb);amb(d,0);for(c=(e=kqb(a.B).b.qc(),Fsb(new Dsb,e));c.a.Sb();){b=Gy(Gy(c.a.Tb(),51).Bd(),88);if(b==d){continue}a.h==1?(b.k.style[UBb]=a.s.a+bAb,undefined):amb(b,a.s.b)}}}
function Jfb(a,b){var c,d,e,f,g,h,i,k,l;h=a.D.c-b;while(h-->0){g=false;c=Gy($X(a.D,b),88);i=c.p;if(!i){d=(k=iqb(a.B).b.qc(),osb(new msb,k));while(d.a.Sb()){e=Gy((l=Gy(d.a.Tb(),51),l.Ad()),36);if(Qy(a.B.sd(e))===(c==null?null:c)){i=e;g=true;break}}if(!i){throw Aob(new yob)}}Gy(a.B.zd(i),88);nO(a,c);if(!g){f=Gy(i,66);s_(a.u,f)}}}
function kgb(a,b,c){var d,e,f,g;a.b=b[1][VTb];a.f=b[1][EUb];a.e=-1;for(e=0;e<c.b;++e){g=Gy((Nrb(e,c.b),c.a[e]),36);f=g.nb.tkPid;d=Gy(a.B.sd(g),88);d.a=$fb(a,f);d.n=agb(a,f)}}
function tgb(a){var b,c;if(Tob(this.k,a)||!(this.nb.style.display!=hAb)){return}c=r3(new p3,this.a.Xc(),this.a.Wc());this.nb.style[aAb]=a;this.k=a;a!=null&&!Tob(a,Pxb)&&hgb(this,(parseInt(this.nb[gAb])||0)-this.q.a);if(this.g){this.i=true}else{fgb(this);b=s3(c,this.a);!b&&g_(this.u,this);this.v&&c.Wc()!=this.a.Wc()&&T4(this,false)}}
function agb(a,b){var c,d,e;if(a.e<0){a.e=0;d=B8(a.f);e=d.length;for(c=0;c<e;++c){a.e+=a.f[d[c]]}a.e==0?(a.d=1/a.B.nd()):(a.d=0)}if(u8(a.f,b)){return a.f[b]/a.e}else{return a.d}}
function Wfb(a){var b,c,d,e,f,g,h;f=0;h=0;g=jY(new gY,a.D);if(a.h==1){f=a.a.Wc();b=a.a.Xc();e=true;while(g.a<g.b.c-1){d=Gy(lY(g),88);if(Vlb(d,1)){h=0}else{h=d.r.Xc()+Ulb(d);if(!lmb(d,a.h)){c=Slb(d);c>h&&(h=c)}}if(!a.w){if(!(b==0))if(h>b){h=b;!e&&(h-=a.s.a);b=0}else{b-=h;!e&&(b-=a.s.a)}e=false}$lb(d,h,f)}}else{h=a.a.Xc();while(g.a<g.b.c-1){d=Gy(lY(g),88);Vlb(d,0)?(f=0):(f=d.r.Wc()+Rlb(d));$lb(d,h,f)}}}
function uI(){var a,c,d;while(jI){d=fi;jI=jI.a;!jI&&(kI=null);if(!d){(K8(),J8).yd(vE,new e9);l$()}else{try{(K8(),J8).yd(vE,new e9);l$()}catch(a){a=lG(a);if(Jy(a,5)){c=a;N5.Kc(c)}else throw a}}}}
function Xfb(a){var b,c,d,e,f,g,h,i,k,l,m,o,p;i=0;h=0;f=0;e=0;for(c=(m=kqb(a.B).b.qc(),Fsb(new Dsb,m));c.a.Sb();){b=Gy(Gy(c.a.Tb(),51).Bd(),88);k=0;l=0;if(Vlb(b,a.h)){a.h==1?(k=(o=b.r,o.Wc()+Rlb(b))):(l=cgb(a,b))}else{l=cgb(a,b);k=(p=b.r,p.Wc()+Rlb(b))}i+=l;h+=k;e=e>k?e:k;f=f>l?f:l}a.h==1?(i+=a.s.a*(a.B.nd()-1)):(h+=a.s.b*(a.B.nd()-1));d=mgb(a,i,h,f,e);a.h==1?(g=d.Xc()-i):(g=d.Wc()-h);g<0&&(g=0);return g}
function Vfb(a){var b,c,d,e,f;e=0;d=0;if(a.h==1){d=a.a.Wc();!a.w&&(e=-1)}else{e=a.a.Xc();!a.v&&(d=-1)}for(c=(f=kqb(a.B).b.qc(),Fsb(new Dsb,f));c.a.Sb();){b=Gy(Gy(c.a.Tb(),51).Bd(),88);gmb(b,e,d)}}
function Dfb(a){var b;Bfb();a.D=YX(new WX,a);a.B=lub(new jub);a.q=Dmb(new Amb,0,0,0,0);a.r=Meb(new Keb,-1);Dlb(new Alb,12,12);a.s=Dlb(new Alb,0,0);a.t=_l((xl(),$doc),kyb);a.nb=_l($doc,kyb);a.nb.style[ABb]=tBb;if(f1().a.g){a.nb.style[rAb]=GBb;a.nb.style[HBb]=IBb}a.z=_l($doc,kyb);a.z.style[ABb]=tBb;f1().a.g&&(a.z.style[rAb]=GBb,undefined);a.nb.appendChild(a.z);b=a.t.style;b[aAb]=mBb;b[cAb]=mBb;b[yUb]=zUb;b[ABb]=tBb;a.z.appendChild(a.t);return a}
function Ifb(a){var b,c;if(!a.jb){return false}Afb.className=a.p+(a.A?AUb:BUb);b=qN(a.nb)+CUb;(a.r.a&1)==1&&(b+=syb+a.o);(a.r.a&4)==4&&(b+=syb+a.l);(a.r.a&8)==8&&(b+=syb+a.m);(a.r.a&2)==2&&(b+=syb+a.n);yfb.className=b;a.z.appendChild(xfb);a.s.b=Afb.offsetHeight||0;a.s.a=Afb.offsetWidth||0;Hmb(a.q,zfb.offsetTop||0);Fmb(a.q,zfb.offsetLeft||0);Gmb(a.q,(yfb.offsetWidth||0)-a.q.c);Emb(a.q,(yfb.offsetHeight||0)-a.q.e);a.z.removeChild(xfb);c=a.z.style;c[mCb]=a.q.c+(Yq(),bAb);c[DUb]=a.q.d+bAb;c[GCb]=a.q.e+bAb;c[oCb]=a.q.b+bAb;return true}
function vgb(a,b){var c,d,e,f,g,h,i,k,l,m,n,o,p,r;this.g=true;Lfb(this,a,b);if(Boolean(a[1][oEb])||Boolean(a[1][pEb])){this.g=false;return}x9(this.c,b);n=_sb(new Wsb,a.length-2);m=Zsb(new Wsb);l=Zsb(new Wsb);i=0;for(h=r4(new o4,a);p=h.b.length-2,p>h.a+1;){f=Hy(t4(h));c=S$(b,f);o=Gy(c,36);d=Gy(this.B.sd(o),88);!d&&(d=Jlb(new Glb,o,this.h));Efb(this,d,i++);G4();if(!Boolean(f[1][oEb])){k=V4(f);d.o=k}if(Vlb(d,this.h)){sy(m.a,m.b++,d);sy(l.a,l.b++,f)}else{this.w?(-1<0&&f1().a.k&&(d.k.style[aAb]=FUb,undefined),Gy(d.p,66).Vc(f,b),undefined):Xlb(d,f,b,this.a.Xc());this.i&&Boolean(f[1][oEb])&&X$(b,d.p)}sy(n.a,n.b++,o)}Jfb(this,i);kgb(this,a,n);ogb(this);egb(this);for(g=0;g<m.b;++g){d=Gy((Nrb(g,m.b),m.a[g]),88);f=Hy((Nrb(g,l.b),l.a[g]));this.w?(-1<0&&f1().a.k&&(d.k.style[aAb]=FUb,undefined),Gy(d.p,66).Vc(f,b),undefined):Xlb(d,f,b,this.a.Xc());G4();Boolean(f[1][oEb])&&X$(b,d.p)}for(e=(r=kqb(this.B).b.qc(),Fsb(new Dsb,r));e.a.Sb();){d=Gy(Gy(e.a.Tb(),51).Bd(),88);kmb(d)}(this.h==1&&this.v||this.h==0&&this.w)&&dgb(this);lgb(this);if(ngb(this)){ogb(this);dgb(this)}Vfb(this);this.z.style[aAb]=this.a.Xc()+(Yq(),bAb);this.z.style[cAb]=this.a.Wc()+bAb;f1().a.g&&(this.z.style[HBb]=IBb,undefined);this.g=false;this.i=false}
var RUb=',marginBottom=',QUb=',marginRight=',PUb=',marginTop=',NUb=',vSpacing=',CUb='-margin',BUb='-off',AUb='-on',xUb='<div style="position:absolute;top:0;left:0;height:0;visibility:hidden;overflow:hidden;"><div style="width:0;height:0;visibility:hidden;overflow:hidden;"><\/div><\/div><div style="position:absolute;height:0;overflow:hidden;"><\/div>',SUb='AsyncLoader3',UUb='CellBasedLayout',VUb='CellBasedLayout$Spacing',WUb='Margins',OUb='Margins [marginLeft=',MUb='Spacing [hSpacing=',XUb='VOrderedLayout',YUb='VOrderedLayout$1',ZUb='WidgetMapImpl$5$1',zUb='both',yUb='clear',EUb='expandRatios',DUb='marginRight',wUb='runCallbacks3',GUb='v-verticallayout',KUb='v-verticallayout-margin-bottom',LUb='v-verticallayout-margin-left',JUb='v-verticallayout-margin-right',IUb='v-verticallayout-margin-top',HUb='v-verticallayout-spacing';_=eI.prototype=new fI;_.gC=qI;_.Qb=uI;_.tI=0;_=e9.prototype=new ph;_.ad=g9;_.gC=h9;_.tI=146;_=wfb.prototype=new SM;_.gC=Nfb;_.Pc=Ofb;_.Qc=Pfb;_.ec=Qfb;_.Vc=Rfb;_.tI=178;_.l=Pxb;_.m=Pxb;_.n=Pxb;_.o=Pxb;_.p=Pxb;_.u=null;_.v=false;_.w=false;_.x=Pxb;_.y=false;_.z=null;_.A=false;var xfb=null,yfb=null,zfb=null,Afb=null;_=vfb.prototype=new wfb;_.Oc=pgb;_.gC=qgb;_.Rc=rgb;_.dc=sgb;_.gc=tgb;_.Sc=ugb;_.Vc=vgb;_.tI=179;_.b=null;_.d=0;_.e=0;_.f=null;_.g=false;_.h=0;_.i=false;_.k=Pxb;_=wgb.prototype=new Q9;_.ed=zgb;_.gC=Agb;_.dd=Bgb;_.tI=180;_.a=null;_=Rib.prototype=new vfb;_.gC=Uib;_.tI=194;_=Alb.prototype=new ph;_.gC=Elb;_.tS=Flb;_.tI=0;_.a=0;_.b=0;_=Amb.prototype=new ph;_.gC=Imb;_.tS=Jmb;_.tI=0;_.a=0;_.b=0;_.c=0;_.d=0;_.e=0;_.f=0;var HA=jnb(AOb,SUb),KE=jnb(TUb,UUb),JE=jnb(TUb,VUb),NE=jnb(TUb,WUb),dE=jnb(BQb,XUb),cE=jnb(BQb,YUb),mD=jnb(ERb,ZUb);rI();