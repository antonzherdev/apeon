function kH(){}
function U8(){}
function zdb(){}
function aeb(){}
function geb(){}
function ueb(){}
function X8(){return jD}
function wH(){return zA}
function Tdb(){return VD}
function eeb(){return SD}
function teb(){return TD}
function yeb(){return UD}
function Udb(){return this.i}
function W8(){return Cdb(new zdb)}
function Vdb(a){return this.o.qd(a)}
function Kdb(a,b){return M4(a.d,a,b)}
function DO(a,b,c){zO(a,b,c)}
function yO(a,b,c,d){wO(a,b);a.rc(b,c,d)}
function ceb(a,b,c,d){a.a=d;a.g=b;a.b=c;return a}
function feb(a,b){return BN(this.a,a,b)}
function deb(a){return Kdb(this.a,a)}
function xeb(a,b){a.a=Kvb(new Ivb);a.b=b;return a}
function nub(a,b){wqb(a);jqb(a,b);return a}
function tO(a,b){a.D=YX(new WX,a);a.nb=b;return a}
function meb(a){if(a.b){return a.b.r.Wc()+Rlb(a.b)}else{return 0}}
function jO(a,b){if(b<0||b>a.D.c){throw Ynb(new Wnb)}}
function wO(a,b){if(b.mb!=a){throw Pnb(new Mnb,GTb)}}
function vO(a,b,c,d){var e;KN(b);e=a.D.c;a.rc(b,c,d);lO(a,b,a.nb,e,true)}
function iO(a,b,c){var d;jO(a,c);if(b.mb==a){d=_X(a.D,b);d<c&&--c}return c}
function neb(a){var b;if(a.b){b=a.b.r.Xc()+Ulb(a.b);return b}else{return 0}}
function jeb(a,b,c){a.k=c;a.h=b[1][ITb];a.d=b[1][JTb];reb(a,b);return a}
function kV(a,b,c){b-=km((xl(),$doc));c-=lm($doc);zO(a,b,c)}
function sO(a){tO(a,_l((xl(),$doc),kyb));a.nb.style[rAb]=GBb;a.nb.style[ABb]=tBb;return a}
function qeb(a){if(!a.c){return false}if(a.g){return false}else{peb(a);return true}}
function Sdb(a){var b;b=Gy(this.o.sd(a),37);return G3(new D3,leb(b)-Ulb(b.b),keb(b)-Rlb(b.b))}
function $db(a,b){var c;c=Gy(this.w.sd(a),88);!!c&&hmb(c,b,this.d);if(!this.p){seb(Gy(this.o.sd(a),37),b);atb(this.d.c,a)}}
function jqb(a,b){var c,d;for(d=b.rd().qc();d.Sb();){c=Gy(d.Tb(),51);a.yd(c.Ad(),c.Bd())}}
function Ndb(a){var b,c;for(c=Pvb(a,0);c.b!=c.d.a;){b=Gy(awb(c),37);peb(b)}}
function Odb(a){var b,c;for(c=Pvb(a,0);c.b!=c.d.a;){b=Gy(awb(c),37);if(!b.f){peb(b);bwb(c)}}}
function leb(a){var b,c;c=a.k.g[a.d];for(b=1;b<a.e;++b){c+=a.k.u+a.k.g[a.d+b]}return c}
function keb(a){var b,c;b=a.k.r[a.h];for(c=1;c<a.i;++c){b+=a.k.v+a.k.r[a.h+c]}return b}
function Rdb(a){var b,c;b=ny(OF,264,-1,a.length,1);for(c=0;c<b.length;++c){b[c]=a[c]}return b}
function Wdb(a,b){var c;c=Gy(this.w.zd(a),88);if(!c){return}emb(c,b);this.w.yd(b,c);this.o.yd(Gy(b,66),Gy(this.o.sd(a),37))}
function lO(a,b,c,d,e){d=iO(a,b,d);KN(b);aY(a.D,b,d);e?JL(c,b.nb,d):c.appendChild(b.nb);MN(b,a)}
function oeb(a,b,c){if(!!a.b&&a.b.jb){yO(a.k.a,a.b,b,c);$lb(a.b,leb(a),keb(a));a.b.a=r9(new o9,a.a);gmb(a.b,leb(a),keb(a))}}
function zO(a,b,c){var d;d=a.nb;if(b==-1&&c==-1){AO(d)}else{d.style[rAb]=zBb;d.style[pAb]=b+bAb;d.style[qAb]=c+bAb}}
function Jdb(a,b){var c,d,e;e=b[1][ITb];d=b[1][JTb];c=a.b[d][e];if(!c){c=jeb(new geb,b,a);a.b[d][e]=c}else{reb(c,b)}return c}
function Jrb(a,b){var c,d;for(c=0,d=a.b;c<d;++c){if(!b?Psb(a,c)==null:(b==null?null:b)===Qy(Psb(a,c))){return c}}return -1}
function AH(){var a,c,d;while(pH){d=fi;pH=pH.a;!pH&&(qH=null);if(!d){(K8(),J8).yd(VD,new U8);l$()}else{try{(K8(),J8).yd(VD,new U8);l$()}catch(a){a=lG(a);if(Jy(a,5)){c=a;N5.Kc(c)}else throw a}}}}
function Cdb(a){a.nb=_l((xl(),$doc),kyb);a.i=_l($doc,kyb);a.a=sO(new RM);a.w=lub(new jub);a.o=lub(new jub);a.c=ceb(new aeb,a,Syb,a);a.f=Kvb(new Ivb);a.s=Kvb(new Ivb);a.nb.appendChild(a.i);a.nb[dAb]=HTb;kT(a,a.a);return a}
function seb(a,b){if(!!b&&!Boolean(b[1][oEb])){cAb in b[1]&&b[1][cAb].indexOf(xDb)!=-1?(a.f=true):(a.f=false);if(aAb in b[1]){a.l=a.g=b[1][aAb].indexOf(xDb)!=-1;cAb in b[1]&&(a.l=false)}else{a.l=!(cAb in b[1]);a.g=false}}}
function Ddb(a){var b,c,d;for(c=0;c<a.b.length;++c){for(d=0;d<a.b[c].length;++d){b=a.b[c][d];if(b){if(!!b.b&&b.l){b.b.nb.style[aAb]=leb(b)+bAb;kmb(b.b)}b.i==1?!b.f&&a.r[d]<meb(b)&&(a.r[d]=meb(b)):Qdb(a,b)}}}Gdb(a);a.m=Rdb(a.r)}
function Pdb(a,b){var c,d,e,f;c=null;for(e=Pvb(a.f,0);e.b!=e.d.a;){d=Gy(awb(e),89);if(d.b<b.e){continue}else{c=d;break}}if(!c){c=xeb(new ueb,b.e);Nvb(a.f,c)}else if(c.b!=b.e){f=xeb(new ueb,b.e);Osb(a.f,Jrb(a.f,c),f);c=f}Lvb(c.a,b)}
function Qdb(a,b){var c,d,e,f;c=null;for(e=Pvb(a.s,0);e.b!=e.d.a;){d=Gy(awb(e),89);if(d.b<b.i){continue}else{c=d;break}}if(!c){c=xeb(new ueb,b.i);Nvb(a.s,c)}else if(c.b!=b.i){f=xeb(new ueb,b.i);Osb(a.s,Jrb(a.s,c),f);c=f}Lvb(c.a,b)}
function Ydb(a){var b,c,d,e;this.nb.style[cAb]=a;if(!Tob(a,this.h)){this.h=a;if(this.p){this.t=true}else{Idb(this);Mdb(this);for(c=(d=iqb(this.o).b.qc(),osb(new msb,d));c.a.Sb();){b=Gy((e=Gy(c.a.Tb(),51),e.Ad()),66);X$(this.d,Gy(b,36))}}}}
function Idb(a){var b,c,d,e,f,g,h;if(!Tob(Pxb,a.h)){h=a.m[0];for(g=1;g<a.m.length;++g){h+=a.v+a.m[g]}b=(parseInt(a.nb[fAb])||0)-a.k;f=b-h;d=0;if(f>0){for(g=0;g<a.r.length;++g){e=~~(f*a.q[g]/1000);a.r[g]=a.m[g]+e;d+=e}f-=d;c=0;while(f>0){++a.r[c%a.r.length];--f;++c}}}}
function xH(){sH=true;rH=(uH(),new kH);wj((tj(),sj),1);!!$stats&&$stats(ak(ETb,_xb,null,null));rH.Qb();!!$stats&&$stats(ak(ETb,FTb,null,null))}
function Hdb(a){var b,c,d,e,f,g,h;if(!Tob(Pxb,a.x)){h=a.l[0];for(g=1;g<a.l.length;++g){h+=a.u+a.l[g]}a.a.nb.style[aAb]=Pxb;b=parseInt(a.a.nb[gAb])||0;f=b-h;d=0;if(f>0){for(g=0;g<a.g.length;++g){e=~~(f*a.e[g]/1000);a.g[g]=a.l[g]+e;d+=e}f-=d;c=0;while(f>0){++a.g[c%a.g.length];--f;++c}}}}
function py(a,b,c,d,e,f,g){var h,i,k,l;k=d[e];i=e==f-1;l=ly(i?g:0,k);wy();zy(l,uy,vy);l.aC=a[e];l.tI=b[e];l.qI=c[e];if(!i){++e;for(h=0;h<k;++h){l[h]=py(a,b,c,d,e,f,g)}}return l}
function Mdb(a){var b,c,d,e,f,g;f=0;g=0;for(d=0;d<a.b.length;++d){g=0;for(e=0;e<a.b[d].length;++e){c=a.b[d][e];!!c&&oeb(c,f,g);g+=a.r[e]+a.v}f+=a.g[d]+a.u}Tob(Pxb,a.x)?(a.a.nb.style[aAb]=f-a.u+bAb,undefined):(a.a.nb.style[aAb]=Pxb,undefined);Tob(Pxb,a.h)?(b=g-a.v):(b=(parseInt(a.nb[fAb])||0)-a.k);a.a.nb.style[cAb]=b+bAb}
function Fdb(a){var b,c,d,e,f,g,h,i,k,l;for(h=Pvb(a.f,0);h.b!=h.d.a;){g=Gy(awb(h),89);for(d=Pvb(g.a,0);d.b!=d.d.a;){c=Gy(awb(d),37);l=c.g?0:neb(c);b=a.g[c.d];for(f=1;f<c.e;++f){b+=a.u+a.g[c.d+f]}if(b<l){i=l-b;k=~~(i/c.e);for(f=0;f<c.e;++f){e=c.d+f;a.g[e]+=k;i-=k}if(i>0){for(f=0;f<c.e;++f){e=c.d+f;a.g[e]+=1;i-=1;if(i==0){break}}}}}}}
function Gdb(a){var b,c,d,e,f,g,h,i,k,l;for(h=Pvb(a.s,0);h.b!=h.d.a;){g=Gy(awb(h),89);for(d=Pvb(g.a,0);d.b!=d.d.a;){c=Gy(awb(d),37);e=c.f?0:meb(c);b=a.r[c.h];for(f=1;f<c.i;++f){b+=a.v+a.r[c.h+f]}if(b<e){i=e-b;l=~~(i/c.i);for(f=0;f<c.i;++f){k=c.h+f;a.r[k]+=l;i-=l}if(i>0){for(f=0;f<c.i;++f){k=c.h+f;a.r[k]+=1;i-=1;if(i==0){break}}}}}}}
function peb(a){var b;b=S$(a.k.d,a.c);if(!a.b||a.b.p!=b){if(a.k.w.qd(b)){a.b=Gy(a.k.w.sd(b),88);a.b.nb.style[aAb]=Pxb;a.b.nb.style[cAb]=Pxb}else{a.b=Jlb(new Glb,Gy(b,36),0);a.k.w.yd(Gy(b,36),a.b);a.b.nb.style[aAb]=Pxb;vO(a.k.a,a.b,0,0)}a.k.o.yd(b,a)}Xlb(a.b,a.c,a.k.d,-1);a.k.t&&(G4(),Boolean(a.c[1][oEb]))&&X$(a.k.d,a.b.p);kmb(a.b);a.k.n.zd(b)}
function reb(a,b){var c,d,e;a.e=UTb in b[1]?b[1][UTb]:1;a.i=dJb in b[1]?b[1][dJb]:1;for(c=0;c<a.e;++c){for(d=0;d<a.i;++d){(c>0||d>0)&&sy(a.k.b[a.d+c],a.h+d,null)}}b=b[2];if(a.c){if(!b){a.b=null}else if(!!a.b&&a.b.p!=S$(a.k.d,b)){a.b=null;e=S$(a.k.d,b);if(a.k.w.qd(e)){a.b=Gy(a.k.w.sd(e),88);a.b.nb.style[aAb]=Pxb;a.b.nb.style[cAb]=Pxb;a.k.o.yd(e,a)}}}a.c=b;seb(a,b)}
function Zdb(a){var b,c,d,e,f,g,h,i,k,l,m,n,o,p,q,r,s,t,u,v;this.nb.style[aAb]=a;if(!Tob(a,this.x)){this.x=a;if(this.p){this.t=true}else{o=Rdb(this.g);Hdb(this);h=false;g=null;for(i=0;i<o.length;++i){if(this.g[i]!=o[i]){f=this.b[i];for(k=0;k<f.length;++k){b=f[k];if(!!b&&!!b.b&&b.l){$lb(b.b,leb(b),keb(b));X$(this.d,b.b.p);kmb(b.b);l=meb(b);if(this.g[i]<o[i]&&l>this.m[k]&&b.i==1){this.m[k]=l;if(l>this.r[k]){this.r[k]=l;h=true}}else if(l<this.m[k]){!g&&(g=tub(new rub));wub(g,kob(k))}}}}}if(g){r=false;for(q=(s=iqb(g.a).b.qc(),osb(new msb,s));q.a.Sb();){p=Gy((t=Gy(q.a.Tb(),51),t.Ad()),43);n=this.m[p.a];m=0;for(e=0;e<this.g.length;++e){d=this.b[e][p.a];!!d&&!d.f&&meb(d)>m&&(m=meb(d))}if(m<n){this.m[p.a]=this.r[p.a]=m;r=true}}if(r){Gdb(this);this.m=Rdb(this.r);h=true}}Mdb(this);for(c=(u=iqb(this.o).b.qc(),osb(new msb,u));c.a.Sb();){b=Gy((v=Gy(c.a.Tb(),51),v.Ad()),66);X$(this.d,Gy(b,36))}h&&Tob(Pxb,this.h)&&T4(this,false)}}}
function Xdb(a){var b,c,d,e,f,g,h,i,k,l,m,n,o,p,q,r,s,t,u,v,w,x;n=false;s=false;t=false;o=parseInt(this.a.nb[fAb])||0;p=parseInt(this.a.nb[gAb])||0;(Tob(Pxb,this.x)||Tob(Pxb,this.h))&&(n=true);g=Zsb(new Wsb);h=Zsb(new Wsb);for(r=a.qc();r.Sb();){q=Gy(r.Tb(),66);c=Gy(this.o.sd(q),37);if(!c.f||!c.g){c.b.nb.style[aAb]=Pxb;c.b.nb.style[cAb]=Pxb;kmb(c.b);imb(c.b);x=neb(c);b=this.g[c.d];for(l=1;l<c.e;++l){b+=this.u+this.g[c.d+l]}if(b<x){n=true;c.e==1?(this.g[c.d]=this.l[c.d]=x):(s=true)}else b!=x&&atb(g,kob(c.d));k=meb(c);b=this.r[c.h];for(l=1;l<c.i;++l){b+=this.v+this.r[c.h+l]}if(b<k){n=true;c.i==1?(this.r[c.h]=this.m[c.h]=k):(t=true)}else b!=k&&atb(h,kob(c.h))}}if(g.b>0){for(e=Xrb(new Urb,g);e.a<e.c.nd();){d=Gy(Zrb(e),43);f=0;for(l=0;l<this.r.length;++l){c=this.b[d.a][l];if(!!c&&!!c.c&&!c.g&&c.e==1){x=neb(c);x>f&&(f=x)}}this.l[d.a]=f}n=true;this.g=Rdb(this.l);Fdb(this);s=false}s&&Fdb(this);if(h.b>0){n=true;for(w=Xrb(new Urb,h);w.a<w.c.nd();){v=Gy(Zrb(w),43);u=this.m[v.a]=0;for(l=0;l<this.g.length;++l){c=this.b[l][v.a];if(!!c&&!!c.c&&!c.f&&c.i==1){i=meb(c);i>u&&(u=i)}}this.m[v.a]=u}this.r=Rdb(this.m);Gdb(this);t=false}t&&Gdb(this);if(n){Hdb(this);Idb(this);Mdb(this);for(l=0;l<this.b.length;++l){for(m=0;m<this.b[l].length;++m){c=this.b[l][m];!!c&&!!c.b&&(c.f||c.g)&&X$(this.d,c.b.p)}}}if((parseInt(this.a.nb[fAb])||0)!=o||(parseInt(this.a.nb[gAb])||0)!=p){return false}else{return true}}
function _db(a,b){var c,d,e,f,g,h,i,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;this.p=true;this.d=b;if(t_(b,this,a,true)){this.p=false;return}x9(this.c,b);this.a.nb.style[aAb]=mBb;v=Meb(new Keb,a[1][KTb]);w=LTb;(v.a&1)==1&&(w+=MTb);(v.a&2)==2&&(w+=NTb);(v.a&4)==4&&(w+=OTb);(v.a&8)==8&&(w+=PTb);this.i.className=w;this.k=(this.i.offsetHeight||0)-(parseInt(this.a.nb[fAb])||0);x=_l((xl(),$doc),kyb);x.className=QTb+(Boolean(a[1][RTb])?STb:TTb);x.style[aAb]=yzb;x.style[cAb]=yzb;this.a.nb.appendChild(x);this.u=x.offsetWidth||0;this.v=x.offsetHeight||0;this.a.nb.removeChild(x);i=a[1][UTb];r=a[1][dJb];this.g=ny(OF,264,-1,i,1);this.r=ny(OF,264,-1,r,1);if(this.b==null){this.b=py([eG,XF],[276,262],[46,37],[i,r],0,2,0)}else if(this.b.length!=i||this.b[0].length!=r){m=py([eG,XF],[276,262],[46,37],[i,r],0,2,0);for(k=0;k<this.b.length;++k){for(l=0;l<this.b[k].length;++l){k<i&&l<r&&(m[k][l]=this.b[k][l])}}this.b=m}this.n=nub(new jub,this.w);d=y8(a[1],VTb);c=0;n=Kvb(new Ivb);p=Kvb(new Ivb);for(k=r4(new o4,a);y=k.b.length-2,y>k.a+1;){o=Hy(t4(k));if(Tob(WTb,o[0])){for(l=r4(new o4,o);z=l.b.length-2,z>l.a+1;){e=Hy(t4(l));if(Tob(XTb,e[0])){f=Jdb(this,e);if(f.c){q=qeb(f);f.a=d[c++];if(!q){kwb(new hwb,f,n.a);++n.b}f.e>1?Pdb(this,f):q&&this.g[f.d]<neb(f)&&(this.g[f.d]=neb(f));if(f.f){kwb(new hwb,f,p.a);++p.b}}}}}}Fdb(this);this.e=y8(a[1],YTb);this.q=y8(a[1],ZTb);this.l=Rdb(this.g);Hdb(this);Odb(n);Ddb(this);Idb(this);Ndb(n);for(g=Pvb(p,0);g.b!=g.d.a;){f=Gy(awb(g),37);u=f.b.p;W$(b,b.g[u.nb.tkPid]);kmb(f.b)}Mdb(this);for(t=(A=iqb(this.n).b.qc(),osb(new msb,A));t.a.Sb();){s=Gy((B=Gy(t.a.Tb(),51),B.Ad()),36);h=Gy(this.w.sd(s),88);this.o.zd(s);this.w.zd(s);KN(h);s_(b,Gy(s,66))}this.n=null;this.p=false;this.t=false}
var OTb=' v-gridlayout-margin-bottom',PTb=' v-gridlayout-margin-left',NTb=' v-gridlayout-margin-right',MTb=' v-gridlayout-margin-top',$Tb='AsyncLoader1',eUb='VGridLayout$1',_Tb='VGridLayout$Cell',bUb='VGridLayout$Cell;',dUb='VGridLayout$SpanList',GTb='Widget must be a child of this panel.',fUb='WidgetMapImpl$2$1',aUb='[Lcom.vaadin.terminal.gwt.client.ui.',cUb='[[Lcom.vaadin.terminal.gwt.client.ui.',YTb='colExpand',XTb='gc',WTb='gr',TTb='off',ZTb='rowExpand',ETb='runCallbacks1',HTb='v-gridlayout',LTb='v-gridlayout-margin',QTb='v-gridlayout-spacing-',UTb='w',JTb='x',ITb='y';_=kH.prototype=new lH;_.gC=wH;_.Qb=AH;_.tI=0;_=RM.prototype;_.rc=DO;_=gV.prototype;_.rc=kV;_=U8.prototype=new ph;_.ad=W8;_.gC=X8;_.tI=143;_=zdb.prototype=new fT;_.Oc=Sdb;_.gC=Tdb;_.wc=Udb;_.Pc=Vdb;_.Qc=Wdb;_.Rc=Xdb;_.dc=Ydb;_.gc=Zdb;_.Sc=$db;_.Vc=_db;_.tI=169;_.b=null;_.d=null;_.e=null;_.g=null;_.h=null;_.k=0;_.l=null;_.m=null;_.n=null;_.p=false;_.q=null;_.r=null;_.t=false;_.u=0;_.v=0;_.x=null;_=aeb.prototype=new Q9;_.ed=deb;_.gC=eeb;_.dd=feb;_.tI=170;_.a=null;_=geb.prototype=new ph;_.gC=teb;_.tI=171;_.a=0;_.b=null;_.c=null;_.d=0;_.e=1;_.f=false;_.g=false;_.h=0;_.i=1;_.k=null;_.l=false;_=ueb.prototype=new ph;_.gC=yeb;_.tI=172;_.b=0;var zA=jnb(AOb,$Tb),TD=jnb(BQb,_Tb),XF=inb(aUb,bUb),eG=inb(cUb,bUb),UD=jnb(BQb,dUb),SD=jnb(BQb,eUb),jD=jnb(ERb,fUb);xH();